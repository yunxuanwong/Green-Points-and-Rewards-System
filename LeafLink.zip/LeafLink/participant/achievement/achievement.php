<?php

    session_start(); 

    $activePage = 'achievement';

    include '../participant_header.php';
    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);
    $participantId = $row['participantId'];

    $pointQuery = "SELECT pointBalance 
                   FROM participant 
                   WHERE participantId = '$participantId'";

    $pointResult = mysqli_query($conn, $pointQuery);
    $row = mysqli_fetch_assoc($pointResult);
    $pointBalance = $row['pointBalance'];

    $historyQuery = "SELECT participantId, pointChange, transactionType, 
                            transactionDate, transactionTime
                     FROM pointtransaction
                     WHERE participantId = '$participantId'
                     ORDER BY transactionDate DESC, transactionTime DESC";

    $historyResult = mysqli_query($conn, $historyQuery);

    $checkBadgeQuery = "SELECT badgeId
                        FROM badge
                        WHERE requiredPoints <= '$pointBalance'";
                        
    $checkBadgeResult = mysqli_query($conn, $checkBadgeQuery);

    while ($badge = mysqli_fetch_assoc($checkBadgeResult)) {

        $badgeId = $badge['badgeId'];
        
        $checkExisting = "SELECT *
                        FROM participantBadge
                        WHERE participantId = '$participantId'
                        AND badgeId = '$badgeId'";

        $existingResult = mysqli_query($conn, $checkExisting);

        if (mysqli_num_rows($existingResult) == 0) {

            $idQuery = "SELECT participantBadgeId
                        FROM participantbadge
                        ORDER BY participantBadgeId DESC
                        LIMIT 1";

            $result = mysqli_query($conn, $idQuery);

            if(mysqli_num_rows($result) == 0){

                $participantBadgeId = "PB000001";

            }else{

                $lastbadge = mysqli_fetch_assoc($result);
                $lastNumber = (int)substr($lastbadge['participantBadgeId'],2);
                $newNumber = $lastNumber + 1;
                $participantBadgeId = "PB".str_pad($newNumber,6,"0",STR_PAD_LEFT);
            
            }

            $awardDate = date("Y-m-d");

            $insertQuery = "INSERT INTO participantBadge(participantBadgeId, 
                                        participantId, badgeId, awardDate)
                            VALUES (
                                '$participantBadgeId',
                                '$participantId',
                                '$badgeId', 
                                '$awardDate'
                                )";

            mysqli_query($conn, $insertQuery);
        }

    }

    $badgeQuery = "SELECT b.badgeName, p.awardDate
                   FROM participantBadge p
                   INNER JOIN badge b ON p.badgeId = b.badgeId
                   WHERE p.participantId = '$participantId'
                   ORDER BY p.awardDate DESC";
    $badgeResult = mysqli_query($conn, $badgeQuery);

?>

<main class= "main-content">

    <div class="main-title">

        <h1>My Achievement</h1>
    
    </div>

    <div class="point-earned">

        <h2>My Points</h2>

        <p><?php echo $row['pointBalance']; ?></p>

    </div>

    <div class="main-subtitle">

        <h2>Point History</h2>

    </div>

    <div class="point-history">

        <div class="point-history-header">

            <p>Point Change</p>
            <p>Transaction Type</p>
            <p>Date</p>
            <p>Time</p>

        </div>

        <?php
        if ($historyResult  && mysqli_num_rows($historyResult) > 0) {
            while ($row = mysqli_fetch_assoc($historyResult)) {
        ?>

                <div class="point-history-row">

                    <p><?php echo $row['pointChange']; ?></p>

                    <p><?php echo $row['transactionType']; ?></p>

                    <p><?php echo $row['transactionDate']; ?></p>
                    
                    <p><?php echo $row['transactionTime']; ?></p>

                </div>

        <?php }
        }else {
        ?>

            <div class="empty-history">

                No point history.

            </div>

        <?php } ?>

    </div>
        
    <div class="main-subtitle">

        <h2>Earned Badge</h2>

    </div>

    <div class="badge-earned">

        <div class="badge-header">

            <p>Badge Name</p>
            <p>Award Date</p>

        </div>

        <?php
        if (mysqli_num_rows($badgeResult) > 0) {
            while ($row = mysqli_fetch_assoc($badgeResult)) {
        ?>

                <div class="badge-row">

                    <p><?php echo $row['badgeName']; ?></p>

                    <p><?php echo $row['awardDate']; ?></p>

                </div>

        <?php }
        }else {
        ?>

            <div class="empty-history">

                No badge history.

            </div>

        <?php } ?>
        
    </div>

</main>

<?php
    include '../participant_footer.php';
?>

