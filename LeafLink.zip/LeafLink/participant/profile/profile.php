<?php

    session_start();

    include '../../database/db_connect.php';
    
    $userId = $_SESSION["userId"];

    $query = "SELECT u.userId, u.fullName, u.emailAddress, u.dateOfBirth, u.phoneNumber, p.faculty 
              FROM `user` u
              LEFT JOIN participant p 
              ON u.userId = p.userId
              WHERE u.userId = '$userId'";

    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    $fullName = $row['fullName'];
    $userId = $row['userId'];
    $emailAddress = $row['emailAddress'];
    $dateOfBirth = $row['dateOfBirth'];
    $phoneNumber = $row['phoneNumber'];
    $faculty = $row['faculty'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>

    <link rel="stylesheet" href="../participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>

    <div class="profile-header">

        <a href="../dashboard.php" class="back-btn">

            <i class="fa-solid fa-arrow-left-long"></i>

        </a>
        
        <h1>My Profile</h1>

    </div>  

    <div class="profile">

        <form action="profile_update.php" method="post">

            <div class="profile-card-top">

                <div class="profile-image">

                    <i class="fa-regular fa-circle-user"></i>

                </div>

                <div class="profile-row">

                    <label for="txtFullName">Full Name:</label>
                    
                    <input 
                        type="text" 
                        id="txtFullName" 
                        name="txtFullName" 
                        value="<?php echo $fullName; ?>" 
                        required
                    >

                </div>

                <div class="profile-row">

                    <label for="txtUserId">User ID:</label>
                    
                    <input 
                        type="text" 
                        id="txtUserId" 
                        name="txtUserId" 
                        value="<?php echo $userId; ?>" 
                        readonly
                    >

                </div>

            </div>

            <div class="profile-card-bottom">

                <div class="profile-title">

                    <h2>Personal Information</h2>

                </div>
                    
                <div class="profile-info">

                    <label for="txtEmailAddress">Email Address:</label>
                    
                    <input 
                        type="email" 
                        id="txtEmailAddress" 
                        name="txtEmailAddress" 
                        value="<?php echo $emailAddress; ?>" 
                        required
                    >

                </div>

                <div class="profile-info">

                    <label for="txtPhoneNumber">Phone Number:</label>
                    
                    <input 
                        type="tel" 
                        id="txtPhoneNumber" 
                        name="txtPhoneNumber" 
                        value="<?php echo $phoneNumber; ?>" 
                        required
                    >

                </div>

                <div class="profile-info">

                    <label for="txtDateOfBirth">Date of Birth:</label>
                    
                    <input 
                        type="date" 
                        id="txtDateOfBirth" 
                        name="txtDateOfBirth" 
                        value="<?php echo $dateOfBirth; ?>" 
                        required
                    >

                </div>

                <div class="profile-info">

                    <label for="txtFaculty">Faculty:</label>
                    
                    <input 
                        type="text" 
                        id="txtFaculty" 
                        name="txtFaculty" 
                        value="<?php echo $faculty; ?>" 
                        readonly
                    >

                </div>

            </div>

            <div class="profile-button">

                <input type="submit" value="Update Profile">

            </div>

        </form>

    </div>
    
</body>
</html>

<?php

    include '../participant_footer.php';

?>