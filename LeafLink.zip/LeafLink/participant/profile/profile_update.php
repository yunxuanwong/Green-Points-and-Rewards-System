<?php

    session_start();

    include '../../database/db_connect.php';
    
    $userId = $_SESSION["userId"];
    
    $fullName = $_POST['txtFullName'];
    $emailAddress = $_POST['txtEmailAddress'];
    $dateOfBirth = $_POST['txtDateOfBirth'];
    $phoneNumber = $_POST['txtPhoneNumber'];

    $query = "UPDATE `user`
              SET fullName='$fullName', 
                  emailAddress='$emailAddress', 
                  dateOfBirth='$dateOfBirth', 
                  phoneNumber='$phoneNumber'
              WHERE userId='$userId'";

    if (mysqli_query($conn, $query)) {

        $_SESSION["fullName"] = $fullName;

        header("Location: ../dashboard.php"); 
        
        exit();

    }else{

        echo "Error updating profile." . mysqli_error($conn);
    
    }

?>