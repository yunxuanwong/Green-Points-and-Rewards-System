<?php

    session_start(); 

    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];

    $teamQuery = "SELECT teamName
                  FROM teammember
                  WHERE participantId = '$participantId'
                  LIMIT 1";

    $teamResult = mysqli_query($conn, $teamQuery);
    $team = mysqli_fetch_assoc($teamResult);

    $teamName = $team['teamName'];

    if (isset($_POST["join"])) {

        $challengeId = $_POST["challengeId"];

        $updateQuery = "UPDATE teammember
                        SET challengeId = '$challengeId'
                        WHERE teamName = '$teamName'";

        $updateResult = mysqli_query($conn, $updateQuery);

        if ($updateResult) {

            $_SESSION['challengeSuccess'] = "Challenge joined successfully.";

        } else {

            $_SESSION['challengeError'] = "Failed to join challenge.";

        }
        
        header("Location: team_challenge.php");

        exit();

    }

    $challengeQuery = "SELECT challengeId, challengeName, startDate, endDate, status, challengePoint
                       FROM teamchallenge
                       WHERE status = 'Active'";

    $challengeResult = mysqli_query($conn, $challengeQuery);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>
  
    <link rel="stylesheet" href="/LeafLink/participant/participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>

    <div class="add-challenge-header">

        <a href="team_challenge.php" class="back-btn">

            <i class="fa-solid fa-arrow-left-long"></i>

        </a>
        
        <h1>Add Challenge</h1>

    </div>  

    <div class="add-challenge">

        <div class="available-challenge">

            <h2>Available Challenges</h2>

            <?php if ($challengeResult && mysqli_num_rows($challengeResult) > 0) {
                
                while ($challenge = mysqli_fetch_assoc($challengeResult)) { ?>

                    <div class="challenge-cards">

                        <div class="challenge-card">

                            <h3><?php echo $challenge['challengeName']; ?></h3>

                            <p>Reward: <?php echo $challenge['challengePoint']; ?> points</p>

                            <p>Start: <?php echo $challenge['startDate']; ?></p>

                            <p>End: <?php echo $challenge['endDate']; ?></p>

                        </div>

                        <form method="POST">

                            <input type="hidden" name="challengeId" value="<?php echo $challenge['challengeId']; ?>">

                            <div class="join-button">

                                <input type="submit" name="join" value="Join">

                            </div>

                        </form>

                    </div>

                <?php } 
                
                } else { 
                    
                ?>

                <div class="challenge-empty">

                    <p>There are no available challenges.</p>

                </div>

            <?php } ?>

        </div>    

    </div>

</body>
</html>

<?php

    include '../participant_footer.php';

?>