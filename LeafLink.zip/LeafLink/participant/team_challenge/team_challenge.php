<?php

    session_start(); 

    $activePage = 'team_challenge';

    include '../participant_header.php';
    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'
                LIMIT 1";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];

    $teamQuery = "SELECT teamMemberId, challengeId, teamName
                FROM teammember
                WHERE participantId = '$participantId'
                LIMIT 1";

    $teamResult = mysqli_query($conn, $teamQuery);
    $hasTeam = mysqli_num_rows($teamResult) > 0;
    $team = $hasTeam ? mysqli_fetch_assoc($teamResult) : null;


    $members = [];

    $challengeResult = null;

    $historyResult = null;

if ($hasTeam) {

        $teamName = $team['teamName'];

        $memberQuery = "SELECT t.participantId, u.fullName
                        FROM teammember t
                        JOIN participant p ON t.participantId = p.participantId
                        JOIN user u ON p.userId = u.userId
                        WHERE t.teamName = '$teamName'";
        $memberResult = mysqli_query($conn, $memberQuery);

        if ($memberResult) {

            while ($memberRow = mysqli_fetch_assoc($memberResult)) {

                $members[] = $memberRow;

            }

        }

        $challengeQuery = "SELECT DISTINCT
                                tc.challengeId,
                                tc.challengeName,
                                tc.startDate,
                                tc.endDate,
                                tc.challengePoint,
                                tc.status
                            FROM teammember tm
                            JOIN teamchallenge tc ON tm.challengeId = tc.challengeId
                            WHERE tm.teamName = '$teamName'
                            AND tc.status != 'Completed'
                            ORDER BY tc.startDate DESC";

        $challengeResult = mysqli_query($conn, $challengeQuery);

        $historyQuery = "SELECT activitysubmission.*, teamchallenge.challengeName
                         FROM activitysubmission
                         JOIN teamchallenge 
                         ON activitysubmission.challengeId = teamchallenge.challengeId
                         WHERE activitysubmission.participantId = '$participantId'";

        $historyResult = mysqli_query($conn, $historyQuery);
    }

?>

<main class= "main-content">

    <div class="main-title">

        <h1>Team Challenge</h1>
    
    </div>

    <div class="teamc-team">
    
        <h2>My Team</h2>

        <?php if (!$hasTeam){ ?>

            <div class="team-empty">

                <p>You have not created or joined a team yet.</p>

            </div>

            <div class="team-plus">

                <a href="create_team.php">

                    <i class="fa-solid fa-plus"></i>
                
                </a>

                <p>Create Team</p>

            </div>

        <?php } else { ?>

            <div class="my-team-info">

                <h3><?php echo $team['teamName']; ?></h3>

                <div class="team-members">

                    <?php foreach ($members as $member): ?>

                        <p><?php echo $member['fullName']; ?></p>

                    <?php endforeach; ?>

                </div>

            </div>

        <?php } ?>

    </div>

    <div class="teamc-challenges">
    
        <h2>Team's Challenges</h2>

        <?php if ($hasTeam){ ?>

            <div class="challenge-plus">

                <a href="add_challenge.php">

                    <i class="fa-solid fa-circle-plus"></i>
                
                </a>

            </div>

            <div class="challenge-list">

                <?php if ($challengeResult && mysqli_num_rows($challengeResult) > 0){
                    
                    while ($challenge = mysqli_fetch_assoc($challengeResult)) {?>

                        <a href="team_challenge_submission.php?challengeId=<?php echo $challenge['challengeId']; ?>"
                           class="challenge-item">

                            <div>

                                <h3><?php echo $challenge['challengeName']; ?></h3>

                                <p>
                                    Reward: <?php echo $challenge['challengePoint']; ?> points
                                </p>

                                <p>
                                    Status: <?php echo $challenge['status']; ?>
                                </p>

                            </div>

                            <i class="fa-solid fa-chevron-right"></i>

                        </a>

                    <?php } ?>

                <?php } else { ?>

                    <div class="challenge-empty">

                        <p>Your team has not joined any challenge yet.</p>

                    </div>    

                <?php } ?>

            </div>

        <?php } else { ?>

            <div class="challenge-empty">

                <p>Create or join a team to participate in challenges.</p>

            </div>

        <?php } ?>

    </div>

    <div class="main-subtitle">

        <h2>Challenge History</h2>

    </div>

    <div class="challenge-history">

        <div class="history-header">

            <p>Challenge Name</p>
            <p>Date</p>
            <p>Time</p>
            <p>Status</p>
            <p>Action</p>

        </div>

        <?php if ($hasTeam){ ?>  

            <div class="chistory-list">

                <?php if ($historyResult && mysqli_num_rows($historyResult) > 0){
                    
                    while ($history = mysqli_fetch_assoc($historyResult)){ 
                        
                        $statusClass = '';

                        if ($history['status'] == 'Pending') {

                            $statusClass = 'status-pending';

                        } elseif ($history['status'] == 'Approved') {
                            
                            $statusClass = 'status-approved';

                        } elseif ($history['status'] == 'Rejected') {

                            $statusClass = 'status-rejected';

                        }                        
                        
                    ?>

                        <div class="chistory-row">

                            <p><?php echo $history['challengeName']; ?></p>

                            <p><?php echo $history['submissionDate']; ?></p>

                            <p><?php echo $history['submissionTime']; ?></p>

                            <p class="<?php echo $statusClass; ?>">

                                <?php echo $history['status']; ?>

                            </p>

                            <p class="chistory-action">

                                <button
                                    type="button"
                                    class="view-button"
                                    onclick="openChallengeModal(
                                        '<?php echo $history['submissionId']; ?>',
                                        '<?php echo $history['challengeName']; ?>',
                                        '<?php echo $history['evidencePhoto']; ?>',
                                        '<?php echo $history['description']; ?>',
                                        '<?php echo $history['status']; ?>',
                                        '<?php echo $history['moderatorId']; ?>',
                                        '<?php echo $history['submissionDate']; ?>',
                                        '<?php echo $history['submissionTime']; ?>'
                                    )"
                                >
                                
                                    <i class="fa-solid fa-eye"></i>

                                </button>
                                    
                            </p>

                        </div>

                    <?php } ?>

                <?php } else { ?>

                    <div class="chistory-empty">

                        <p>You don't have any history.</p>
                        
                    </div>

                <?php } ?>

            </div>

        <?php } else { ?>

            <div class="chistory-empty">

                <p>You don't have any history.</p>
                
            </div>

        <?php } ?>

    </div>

    <div id="historyPopup" class="history-popup">

        <div class="history-popup-content">

            <div class="history-popup-header">

                <h2>Challenge Submission History</h2>

                <button
                    type="button"
                    class="popup-close"
                    onclick="closeChallengePopup()">
                    &times;
                </button>

            </div>

            <div class="history-popup-body">

                <div class="history-item">

                    <h3>Challenge Name</h3>

                    <p id="historyChallengeName"></p>

                </div>

                <div class="history-item">

                    <h3>Evidence Photo</h3>

                    <div id="historyEvidence"></div>

                </div>

                <div class="history-item">

                    <h3>Description</h3>

                    <p id="historyDescription"></p>

                </div>

                <div class="history-item">

                    <h3>Status</h3>

                    <p id="historyStatus"></p>

                </div>

                <div class="history-item">

                    <h3>Moderator ID</h3>

                    <p id="historyModerator"></p>

                </div>


                <div class="history-item">

                    <h3>Submission Date</h3>

                    <p id="historyDate"></p>

                </div>


                <div class="history-item">

                    <h3>Submission Time</h3>
                    
                    <p id="historyTime"></p>

                </div>

            </div>

        </div>

    </div>
    
</main>

<?php

    include '../participant_footer.php';

?>

