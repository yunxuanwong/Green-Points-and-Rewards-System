<?php

    session_start(); 

    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];

    if(isset($_POST["create"])) {

        $teamMemberIdQuery = "SELECT teamMemberId
                              FROM teammember
                              ORDER BY teamMemberId DESC
                              LIMIT 1";

        $teamMemberIdResult = mysqli_query($conn, $teamMemberIdQuery);

        if(mysqli_num_rows($teamMemberIdResult) == 0){

            $teamMemberId = "TM000001";

        }else{

            $lastCreate = mysqli_fetch_assoc($teamMemberIdResult);
            $lastNumber = (int)substr($lastCreate['teamMemberId'],2);
            $newNumber = $lastNumber + 1;
            $teamMemberId = "TM".str_pad($newNumber,6,"0",STR_PAD_LEFT);
        
        }

        $teamName = $_POST['txtTeamName'];

        $fullName1 = $_POST['fullName1'];
        $emailAddress1 = $_POST['emailAddress1'];
        $phoneNumber1 = $_POST['phoneNumber1'];

        $fullName2 = $_POST['fullName2'];
        $emailAddress2 = $_POST['emailAddress2'];
        $phoneNumber2 = $_POST['phoneNumber2'];

        $fullName3 = $_POST['fullName3'];
        $emailAddress3 = $_POST['emailAddress3'];
        $phoneNumber3 = $_POST['phoneNumber3'];        

        $teamCheck = "SELECT teamName
                      FROM teammember
                      WHERE teamName = '$teamName'
                      LIMIT 1";

        $teamResult = mysqli_query($conn, $teamCheck);

        if (mysqli_num_rows($teamResult) > 0) {

            $error = "Team name already exists.";

        } else {

            $query = "SELECT p.participantId
                      FROM participant p
                      JOIN user u ON p.userId = u.userId
                      WHERE u.fullName = '$fullName1'
                      AND u.emailAddress = '$emailAddress1'
                      AND u.phoneNumber = '$phoneNumber1'";

            $result = mysqli_query($conn, $query);
            $member1 = mysqli_fetch_assoc($result);

            $query = "SELECT p.participantId
                      FROM participant p
                      JOIN user u ON p.userId = u.userId
                      WHERE u.fullName = '$fullName2'
                      AND u.emailAddress = '$emailAddress2'
                      AND u.phoneNumber = '$phoneNumber2'";

            $result = mysqli_query($conn, $query);
            $member2 = mysqli_fetch_assoc($result);

            $query = "SELECT p.participantId
                      FROM participant p
                      JOIN user u ON p.userId = u.userId
                      WHERE u.fullName = '$fullName3'
                      AND u.emailAddress = '$emailAddress3'
                      AND u.phoneNumber = '$phoneNumber3'";

            $result = mysqli_query($conn, $query);
            $member3 = mysqli_fetch_assoc($result);

            if (!$member1 || !$member2 || !$member3) {

                $_SESSION['createError'] = "Invalid team member information.";
                
                header("Location: create_team.php");
                
                exit();

            }

            $query = "INSERT INTO teammember (
                        teamMemberId,
                        participantId,
                        challengeId,
                        teamName
                    )
                    VALUES (
                        '$teamMemberId', 
                        '{$member1['participantId']}', 
                        NULL, 
                        '$teamName'
                    )";
            
            $insert = mysqli_query($conn, $query);

            $number = (int)substr($teamMemberId, 2) + 1;
            $teamMemberId = "TM" . str_pad($number, 6, "0", STR_PAD_LEFT);

            $query = "INSERT INTO teammember (
                        teamMemberId,
                        participantId,
                        challengeId,
                        teamName
                    )
                    VALUES (
                        '$teamMemberId', 
                        '{$member2['participantId']}', 
                        NULL, 
                        '$teamName'
                    )";
            
            $insert = mysqli_query($conn, $query);

            $number = (int)substr($teamMemberId, 2) + 1;
            $teamMemberId = "TM" . str_pad($number, 6, "0", STR_PAD_LEFT);

            $query = "INSERT INTO teammember (
                        teamMemberId,
                        participantId,
                        challengeId,
                        teamName
                    )
                    VALUES (
                        '$teamMemberId', 
                        '{$member3['participantId']}', 
                        NULL, 
                        '$teamName'
                    )";
            
            $insert = mysqli_query($conn, $query);

            if ($insert) {

                $_SESSION['createSuccess'] = "Team created successfully.";
            
            } else {

                $_SESSION['createError'] = "Failed to create team.";
            
            }

            header("Location: team_challenge.php");
            
            exit();

        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>
  
    <link rel="stylesheet" href="/LeafLink/participant/participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>
    
    <div class="create-team-header">

        <a href="team_challenge.php" class="back-btn">

            <i class="fa-solid fa-arrow-left-long"></i>

        </a>
        
        <h1>Create Team</h1>

    </div>

    <form action="create_team.php" method="POST">

        <div class="create-team">

            <div class="create-form">

                <div class="input-teamName">

                    <label for="txtTeamName">Team Name</label>

                    <input 
                        type="text"
                        id="txtTeamName"
                        name="txtTeamName"
                        required
                    >

                </div>

                <div class="input-teamMember">

                    <h3>Member 1</h3>
                    <input type="text" id="fullName1" name="fullName1" placeholder="Full Name" required>
                    <input type="email" id="emailAddress1" name="emailAddress1" placeholder="Email Address" required>
                    <input type="tel" id="phoneNumber1" name="phoneNumber1" placeholder="Phone Number" required>

                    <h3>Member 2</h3>
                    <input type="text" id="fullName2" name="fullName2" placeholder="Full Name" required>
                    <input type="email" id="emailAddress2" name="emailAddress2" placeholder="Email Address" required>
                    <input type="tel" id="phoneNumber2" name="phoneNumber2" placeholder="Phone Number" required>

                    <h3>Member 3</h3>
                    <input type="text" id="fullName3" name="fullName3" placeholder="Full Name" required>
                    <input type="email" id="emailAddress3" name="emailAddress3" placeholder="Email Address" required>
                    <input type="tel" id="phoneNumber3" name="phoneNumber3" placeholder="Phone Number" required>

                </div>
                
            </div>

            <div class="create-button">

                <input type="submit" name="create" value="Create">

            </div>
            
        </div>

    </form>

</body>
</html>

<?php

    include '../participant_footer.php';

?>