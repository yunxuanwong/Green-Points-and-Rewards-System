<?php

    session_start(); 

    $activePage = 'activity_status';

    include '../participant_header.php';
    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);

    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];

    $pendingQuery = "SELECT activitysubmission.*, activity.activityName
                     FROM activitysubmission
                     JOIN activity 
                     ON activitysubmission.activityId = activity.activityId
                     WHERE activitysubmission.participantId = '$participantId'
                     AND activitysubmission.status = 'Pending'";
    
    $pendingResult = mysqli_query($conn, $pendingQuery);

    $approvedQuery = "SELECT activitysubmission.*, activity.activityName
                      FROM activitysubmission
                      JOIN activity 
                      ON activitysubmission.activityId = activity.activityId
                      WHERE activitysubmission.participantId = '$participantId'
                      AND activitysubmission.status = 'Approved'";
    
    $approvedResult = mysqli_query($conn, $approvedQuery);

    $rejectedQuery = "SELECT activitysubmission.*, activity.activityName
                      FROM activitysubmission
                      JOIN activity 
                      ON activitysubmission.activityId = activity.activityId
                      WHERE activitysubmission.participantId = '$participantId'
                      AND activitysubmission.status = 'Rejected'";
    
    $rejectedResult = mysqli_query($conn, $rejectedQuery);

    $historyQuery = "SELECT activitysubmission.*, activity.activityName
                        FROM activitysubmission
                        JOIN activity 
                        ON activitysubmission.activityId = activity.activityId
                        WHERE activitysubmission.participantId = '$participantId'";
    
    $historyResult = mysqli_query($conn, $historyQuery);

?>

<main class= "main-content">

    <div class="main-title">

        <h1>Activity Status</h1>
    
    </div>

    <div class="activity-status">

        <div class="status-tabs">

            <button class="tab-button" onclick="openTab(event, 'pending')">
                
                Pending

            </button>

            <button class="tab-button" onclick="openTab(event, 'approved')">

                Approved

            </button>

            <button class="tab-button" onclick="openTab(event, 'rejected')">

                Rejected

            </button>                

        </div>

        <div id="pending" class="tab-content">

            <?php  

            if (mysqli_num_rows($pendingResult) > 0) {

                while ($row = mysqli_fetch_assoc($pendingResult)) {

            ?>

                    <div class="status-row">

                        <p><?php echo $row['activityName']; ?></p>
                        
                        <p><?php echo $row['submissionDate']; ?></p>
                        
                        <p><?php echo $row['submissionTime']; ?></p>

                    </div>

            <?php }

            }else {

            ?>

                <div class="empty-status">

                    No pending activities.

                </div>

            <?php } ?>

        </div>

        <div id="approved" class="tab-content">

            <?php  

            if (mysqli_num_rows($approvedResult) > 0) {

                while ($row = mysqli_fetch_assoc($approvedResult)) {

            ?>

                    <div class="status-row">

                        <p><?php echo $row['activityName']; ?></p>
                        
                        <p><?php echo $row['submissionDate']; ?></p>
                        
                        <p><?php echo $row['submissionTime']; ?></p>

                    </div>

            <?php }

            }else {

            ?>

                <div class="empty-status">

                    No approved activities.

                </div>

            <?php } ?>

        </div>

        <div id="rejected" class="tab-content">

            <?php  

            if (mysqli_num_rows($rejectedResult) > 0) {
                
                while ($row = mysqli_fetch_assoc($rejectedResult)) {

            ?>

                    <div class="status-row">

                        <p><?php echo $row['activityName']; ?></p>
                        
                        <p><?php echo $row['submissionDate']; ?></p>
                        
                        <p><?php echo $row['submissionTime']; ?></p>

                    </div>

            <?php }

            }else {

            ?>

                <div class="empty-status">

                    No rejected activities.

                </div>

            <?php } ?>
            
        </div>

    </div>

    <div class="main-subtitle">

        <h2>Activity History</h2>

    </div>

    <div class="activity-history">

        <div class="history-header">

            <p>Activity Name</p>
            <p>Date</p>
            <p>Time</p>
            <p>Status</p>
            <p>Action</p>

        </div>

        <?php  

        while ($row = mysqli_fetch_assoc($historyResult)) {

            $statusClass = '';

            if ($row['status'] == 'Pending') { 

                $statusClass = 'status-pending';

            } elseif ($row['status'] == 'Approved') {

                $statusClass = 'status-approved';

            } elseif ($row['status'] == 'Rejected') {

                $statusClass = 'status-rejected';

            }

        ?>

            <div class="history-row">

                <p><?php echo $row['activityName']; ?></p>

                <p><?php echo $row['submissionDate']; ?></p>

                <p><?php echo $row['submissionTime']; ?></p>

                <p class="<?php echo $statusClass; ?>">

                    <?php echo $row['status']; ?>

                </p>

                <p class="history-action">

                    <button
                        type="button"
                        class="view-button"
                        onclick="openSubmissionModal(
                            '<?php echo $row['submissionId']; ?>',
                            '<?php echo $row['activityName']; ?>',
                            '<?php echo $row['evidencePhoto']; ?>',
                            '<?php echo $row['description']; ?>',
                            '<?php echo $row['status']; ?>',
                            '<?php echo $row['moderatorId']; ?>',
                            '<?php echo $row['submissionDate']; ?>',
                            '<?php echo $row['submissionTime']; ?>'
                        )"
                    >

                        <i class="fa-solid fa-eye"></i>

                    </button>
                        
                </p>

            </div>

        <?php } ?>

    </div>

    <div id="historyPopup" class="history-popup">

        <div class="history-popup-content">

            <div class="history-popup-header">

                <h2>Activity Submission History</h2>

                <button
                    type="button"
                    class="popup-close"
                    onclick="closeHistoryPopup()">
                    &times;
                </button>

            </div>

            <div class="history-popup-body">

                <div class="history-item">

                    <h3>Activity Name</h3>

                    <p id="historyActivityName"></p>

                </div>

                <div class="history-item">

                    <h3>Evidence Photo</h3>

                    <div id="historyEvidence"></div>

                </div>

                <div class="history-item">

                    <h3>Description</h3>

                    <p id="historyDescription"></p>

                </div>

                <div class="history-item">

                    <h3>Status</h3>

                    <p id="historyStatus"></p>

                </div>

                <div class="history-item">

                    <h3>Moderator ID</h3>

                    <p id="historyModerator"></p>

                </div>

                <div class="history-item">

                    <h3>Submission Date</h3>

                    <p id="historyDate"></p>

                </div>

                <div class="history-item">

                    <h3>Submission Time</h3>

                    <p id="historyTime"></p>

                </div>

            </div>

        </div>

    </div>

</main>

<script src="../participant_script.js"></script>

<?php

    include '../participant_footer.php';
    
?>