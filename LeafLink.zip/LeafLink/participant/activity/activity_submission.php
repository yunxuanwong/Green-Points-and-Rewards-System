<?php

    session_start(); 

    include '../../database/db_connect.php';

    $activityId = $_POST['activityId'] ?? $_GET['activityId'] ?? '';

    $userId = $_SESSION["userId"];

    $participantQuery = "SELECT participantId 
                         FROM participant 
                         WHERE userId = '$userId'";

    $participantResult = mysqli_query($conn, $participantQuery);
    $participantRow = mysqli_fetch_assoc($participantResult);

    $participantId = $participantRow['participantId'];

    if(isset($_POST["submit"])) {

        $submissionIdQuery = "SELECT submissionId
                              FROM activitysubmission
                              ORDER BY submissionId DESC
                              LIMIT 1";

        $submissionIdResult = mysqli_query($conn, $submissionIdQuery);

        if(mysqli_num_rows($submissionIdResult) == 0){

            $submissionId = "S000001";

        }else{

            $lastSubmission = mysqli_fetch_assoc($submissionIdResult);
            $lastNumber = (int)substr($lastSubmission['submissionId'],2);
            $newNumber = $lastNumber + 1;
            $submissionId = "S".str_pad($newNumber,6,"0",STR_PAD_LEFT);
        
        }

        $target_directory = "../../uploads/evidence/";

        $originalName = basename($_FILES["evidencePhoto"]["name"]);
        
        $target_file = $target_directory . $originalName;
       
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        
        $check = getimagesize($_FILES["evidencePhoto"]["tmp_name"]);

        if ($check === false) {

            die("File is not a valid image.");
            
        }

        if (!move_uploaded_file(
            $_FILES["evidencePhoto"]["tmp_name"],
            $target_file)) {

            die("Sorry, there was an error uploading your file.");
        
        }

        $evidencePhoto = $originalName;
        $description = $_POST['txtDescription'];
        $status = "Pending";
        $moderatorId = NULL;
        $submissionDate = date("Y-m-d");
        $submissionTime = date("H:i:s");
        $challengeId = NULL;

        $query = "INSERT INTO activitysubmission (
                    submissionId,
                    participantId,
                    activityId,
                    evidencePhoto,
                    description,
                    status,
                    moderatorId,
                    submissionDate,
                    submissionTime,
                    challengeId
                )
                VALUES (
                    '$submissionId', 
                    '$participantId', 
                    '$activityId', 
                    '$evidencePhoto', 
                    '$description', 
                    '$status', 
                    NULL, 
                    '$submissionDate', 
                    '$submissionTime',
                    NULL
                )";
        
        $insert = mysqli_query($conn, $query);

        if ($insert) {
            
            $_SESSION['submissionSuccess'] = "Activity submitted successfully.";

        } else {

            $_SESSION['submissionError'] = "Failed to submit activity.";

        }

        header("Location: activity.php");

        exit();

    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>
  
    <link rel="stylesheet" href="/LeafLink/participant/participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>
    
    <div class="activity-submission-header">

        <a href="activity_details.php?activityId=<?php echo $activityId; ?>" class="back-btn">

            <i class="fa-solid fa-arrow-left-long"></i>
        
        </a>
        
        <h1>Submit Activity</h1>

    </div>

    <form action="activity_submission.php" method="POST" enctype="multipart/form-data">

        <input type="hidden" name="activityId" value="<?php echo $activityId; ?>">

        <div class="activity-submission">

            <div class="submission-evidence">

                <label for="evidencePhoto">Evidence</label>

                <p>Upload a photo as evidence</p>

                <input 
                    type="file"
                    id="evidencePhoto"
                    name="evidencePhoto"
                    accept=".jpg, .jpeg, .png"
                    required
                >

            </div>

            <div class="submission-description">

                <label for="txtDescription">Description</label>

                <p>Describe what you did...</p>

                <input 
                    type="text"
                    id="txtDescription"
                    name="txtDescription"
                    required
                >

            </div>

            <div class="submission-button">

                <input type="submit" name="submit" value="Submit"
                >

            </div>

        </div>

    </form>

</body>

<?php

    include '../participant_footer.php';

?>