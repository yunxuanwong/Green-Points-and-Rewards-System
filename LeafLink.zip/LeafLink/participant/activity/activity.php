<?php

    session_start(); 

    $activePage = 'activity';

    include '../participant_header.php';
    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $categoryQuery = "SELECT DISTINCT category 
                      FROM activity";

    $categoryResult = mysqli_query($conn, $categoryQuery);

    $category = $_GET['category'] ?? '';

    $activityResult = null;

    if ($category != '') {

        $sql = "SELECT activityId, activityName
                FROM activity
                WHERE category='$category' 
                AND status='Active'";

        $activityResult = mysqli_query($conn, $sql);

    }

?>


<main class="main-content">

    <div class="main-title">

        <h1>Categories</h1>
    
    </div>

    <div class="category-cards">

        <?php while ($row = mysqli_fetch_assoc($categoryResult)) { 

                $active = ($category == $row['category']) ? 'active' : '';

        ?>

            <a href="activity.php?category=<?php echo $row['category']; ?>">     

                <div class="category-card <?php echo $active; ?>">

                    <div class="category-name">

                        <?php echo $row["category"]; ?>
                    
                    </div>

                </div>

            </a>

        <?php } ?>

    </div>

    <?php if ($activityResult) { ?>

        <div class="main-subtitle">

            <h2>Activities</h2>
        
        </div>

        <div class="activity-cards">

            <?php while ($activity = mysqli_fetch_assoc($activityResult)) { ?>
                
                <a href="activity_details.php?activityId=<?php echo $activity['activityId']; ?>">

                    <div class="activity-card">

                        <div class="activity-name">
                            
                            <?php echo $activity["activityName"]; ?>
                        
                        </div>

                        <div class="activity-plus">

                            <i class="fa-solid fa-circle-plus"></i>
                        
                        </div>

                    </div>

                </a>

            <?php } ?>

        </div>

    <?php } ?>
    
</main>

<?php

    include '../participant_footer.php';
    
?>