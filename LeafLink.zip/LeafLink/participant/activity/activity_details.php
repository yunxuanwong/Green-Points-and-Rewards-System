<?php

    session_start(); 

    include '../../database/db_connect.php';

    $activityId = $_GET["activityId"];

    $query = "SELECT activityId, activityName, description, category, pointsReward, rules, status
              FROM activity
              WHERE activityId = '$activityId'";

    $result = mysqli_query($conn, $query);
    $activity = mysqli_fetch_assoc($result);
    
    $activityName = $activity['activityName'];
    $description = $activity['description'];
    $category = $activity['category'];
    $pointsReward = $activity['pointsReward'];
    $rules = $activity['rules'];
    $status = $activity['status'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>
  
    <link rel="stylesheet" href="/LeafLink/participant/participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>

    <div class="activity-details-header">

        <a href="activity.php" class="back-btn">

            <i class="fa-solid fa-arrow-left-long"></i>
        
        </a>
        
        <h1>Green Activities</h1>

    </div>  

    <section class="activity-details">

        <div class="details-top">

            <h2><?php echo $activityName; ?></h2>
            
            <p><?php echo $description; ?></p>

        </div>

        <div class="details-bottom">

            <div class="activity-rules">

                <h3>Rules</h3>
                
                <p><?php echo $rules; ?></p> 

            </div>

            <div class="activity-reward">

                <h3>Point Reward</h3>
                
                <p><?php echo $pointsReward; ?></p>

            </div>

        </div>

        <div class="details-button">

            <a href="activity_submission.php?activityId=<?php echo $activityId; ?>">

                <i class="fa-solid fa-arrow-up-from-bracket"></i>
                
                Upload
                
            </a>
            
        </div>

    </section>

</body>
</html>

<?php

    include '../participant_footer.php';

?>