<?php

    if (session_status() == PHP_SESSION_NONE) {

        session_start();
        
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>
  
    <link rel="stylesheet" href="/LeafLink/participant/participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>
    
    <header>

        <div class="header-container">

            <a href="/LeafLink/participant/dashboard.php" class="logo">
                
                <img src="/LeafLink/images/logo.jpg" alt="LeafLink Logo">
            
            </a>

            <nav>

                <ul>

                    <li>
                        <a href="/LeafLink/participant/profile/profile.php" 
                        class="profile-link <?php echo ($activePage == 'dashboard') ? 'active' : ''; ?>">
                        
                        <i class="fa-regular fa-circle-user"></i>
                        
                        <?php echo $_SESSION['fullName']; ?>
                        
                        <i class="fa-solid fa-chevron-down"></i>
                    
                        </a>
                
                    </li>
                
                </ul>
            
            </nav>

        </div>

    </header>
        
    <div class="page-container">

        <aside class="sidebar">

            <div class="sidebar-menu">

                <a href="/LeafLink/participant/dashboard.php" 
                    class="sidebar-link <?php echo ($activePage == 'dashboard') ? 'active' : ''; ?>">
                    
                    <i class="fa-solid fa-house"></i>
                    
                    Dashboard
                
                </a>

                <a href="/LeafLink/participant/activity/activity.php" 
                class="sidebar-link <?php echo ($activePage == 'activity') ? 'active' : ''; ?>">
                    
                    <i class="fa-solid fa-leaf"></i>
                    
                    Green Activity
                
                </a>

                <a href="/LeafLink/participant/team_challenge/team_challenge.php" 
                class="sidebar-link <?php echo ($activePage == 'team_challenge') ? 'active' : ''; ?>">
                    
                    <i class="fa-solid fa-people-group"></i>
                    
                    Team Challenge
                
                </a>

                <a href="/LeafLink/participant/activity_status/activity_status.php" 
                class="sidebar-link <?php echo ($activePage == 'activity_status') ? 'active' : ''; ?>">

                    <i class="fa-solid fa-clock"></i>
                    
                    Activity Status

                </a>

                <a href="/LeafLink/participant/achievement/achievement.php" 
                class="sidebar-link <?php echo ($activePage == 'achievement') ? 'active' : ''; ?>">

                    <i class="fa-solid fa-award"></i>
                    
                    Achievement

                </a>

                <a href="/LeafLink/participant/reward/reward.php"
                class="sidebar-link <?php echo ($activePage == 'reward') ? 'active' : ''; ?>">

                    <i class="fa-solid fa-gift"></i>
                    
                    Reward

                </a>

                <a href="#" 
                class="sidebar-link"
                onclick="openLogoutPopup(); return false;">

                    <i class="fa-solid fa-right-from-bracket"></i>
                    
                    Logout

                </a>

            </div>

        </aside>

    </div>

<div id="logoutPopup" class="logout-popup">

    <div class="logout-popup-content">

        <button
            type="button"
            class="popup-close"
            onclick="closeLogoutPopup()">
            &times;
        </button>

        <p>Are you confirm to logout?</p>

        <div class="logout-button">

            <button
                type="button"
                class="logout-cancel"
                onclick="closeLogoutPopup()">
                Cancel
            </button>

            <a
                href="/LeafLink/logout.php"
                class="logout-confirm">
                Logout
            </a>

        </div>

    </div>

</div>

<script src="/LeafLink/participant/participant_script.js"></script>
