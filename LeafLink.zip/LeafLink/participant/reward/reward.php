<?php

    session_start(); 

    $submissionError = $_SESSION['submissionError'] ?? '';
    unset($_SESSION['submissionError']);

    $submissionSuccess = $_SESSION['submissionSuccess'] ?? '';
    unset($_SESSION['submissionSuccess']);

    $activePage = 'reward';

    include '../participant_header.php';
    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId, pointBalance
                FROM participant 
                WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];
    $pointBalance = $row['pointBalance'];

    $rewardId = $_GET['rewardId'] ?? '';

    if ($rewardId == '') {

        $rewardQuery = "SELECT * FROM reward
                        WHERE status='Active'
                        LIMIT 1";

    } else {

        $rewardQuery = "SELECT * FROM reward
                        WHERE rewardId='$rewardId'
                        AND status='Active'";

    }

    $rewardResult = mysqli_query($conn, $rewardQuery);
    $reward = mysqli_fetch_assoc($rewardResult);

    if ($rewardId == '' && $reward) {

        $rewardId = $reward['rewardId'];

    }

    $rewardQuery = "SELECT rewardId, rewardName
                    FROM reward
                    WHERE status='Active'";

    $rewardsResult = mysqli_query($conn, $rewardQuery);

?>

<main class= "main-content">

    <div class="main-title">

        <h1>Reward</h1>

        <div class="reward-top">

            <a href="../achievement/achievement.php" class="top-button">

                <?php echo $pointBalance; ?> points

            </a>

            <a href="redemption_history.php" class="top-button">

                View History

            </a>    

        </div>
    
    </div>

    <div class="reward-sidebar">

        <?php  

        while ($row = mysqli_fetch_assoc($rewardsResult)) {

            $active = ($rewardId == $row['rewardId']) ? 'active' : '';

        ?>

            <a
                href="reward.php?rewardId=<?php echo $row['rewardId']; ?>"
                class="reward-item <?php echo $active; ?>"
            >

                <?php echo $row['rewardName']; ?>

            </a>

        <?php } ?>
        
    </div>

    <div class="reward-info"> 

        <?php if ($reward) { ?>

            <div class="reward-photo">

                <img src="../../uploads/rewards/<?php echo $reward['image']; ?>">

            </div>

            <div class="reward-details">

                <div class="reward-description">

                    <h3>Description</h3>

                    <p><?php echo $reward['description']; ?></p>

                </div>

                <div class="reward-requirements">

                    <h3>Requirements</h3>
                    
                    <p><?php echo $reward['pointRequired']; ?> points</p>

                </div>

            </div>

            <div class="reward-button">

                <button
                    type="button"
                    onclick="openRedeemPopup('<?php echo $rewardId; ?>')">
                    Redeem
                </button>
                
            </div>

        <?php } ?>

    </div>

</main>

<div id="messagePopup" 
    class="message-popup" 
    <?php echo $submissionError ? 'style="display: flex;"' : ''; ?>
>

    <div class="message-popup-content">

        <button
            type="button"
            class="popup-close"
            onclick="closeMessagePopup()">
            &times;
        </button>

        <h3>Redemption Failed</h3>

        <p><?php echo $submissionError; ?></p>

    </div>

</div>

<div id="redemptionPopup" class="redemption-popup">

    <div class="redemption-popup-content">

        <button
            type="button"
            class="popup-close"
            onclick="closeRedeemPopup()">
            &times;
        </button>

        <p>Are you confirm to redeem this reward?</p>

        <form method="POST" action="reward_redemption.php">

            <input 
                type="hidden" 
                id="redeemRewardId"
                name="rewardId" 
                value=""
            >

            <div class="redemption-button">
                
                <input 
                    type="submit" 
                    name="submit" 
                    value="Confirm"
                >

            </div>

        </form>

    </div>

</div>



<?php

    include '../participant_footer.php';

?>