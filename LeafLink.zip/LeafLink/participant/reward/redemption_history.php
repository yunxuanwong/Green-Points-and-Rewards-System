<?php

    session_start(); 

    include '../../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];

    $redemptionQuery = "SELECT rewardredemption.*, reward.rewardName, reward.pointRequired
                        FROM rewardredemption
                        JOIN reward 
                        ON rewardredemption.rewardId = reward.rewardId
                        WHERE rewardredemption.participantId = '$participantId'";
    $redemptionResult = mysqli_query($conn, $redemptionQuery);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LeafLink</title>
  
    <link rel="stylesheet" href="/LeafLink/participant/participant_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
<body>

    <div class="redemption-history-header">

        <a href="reward.php" class="back-btn">

            <i class="fa-solid fa-arrow-left-long"></i>
        
        </a>
        
        <h1>Redemption History</h1>

    </div>  

    <div class="redemption-history">

        <div class="redemption-table">

            <div class="redemption-header">

                <p>Reward Name</p>
                <p>Date</p>
                <p>Time</p>
                <p>Point Required</p>
                <p>Status</p>

            </div>

            <?php  

            while ($row = mysqli_fetch_assoc($redemptionResult)) {

                $statusClass = '';

                if ($row['status'] == 'Pending') {

                    $statusClass = 'status-pending';


                } elseif ($row['status'] == 'Approved') {

                    $statusClass = 'status-approved';

                } elseif ($row['status'] == 'Rejected') {

                    $statusClass = 'status-rejected';

                }

            ?>

                <div class="redemption-row">

                    <p><?php echo $row['rewardName']; ?></p>

                    <p><?php echo $row['redeemedDate']; ?></p>

                    <p><?php echo $row['redeemedTime']; ?></p>

                    <p><?php echo $row['pointRequired']; ?></p>

                    <p class="<?php echo $statusClass; ?>">
                        
                        <?php echo $row['status']; ?>
                    
                    </p>

                </div>

            <?php } ?>

        </div>

    </div>

</body>

<?php

    include '../participant_footer.php';
    
?>
