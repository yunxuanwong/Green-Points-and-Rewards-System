<?php

    session_start(); 

    include '../../database/db_connect.php';

    $rewardId = $_POST['rewardId'] ?? $_GET['rewardId'] ?? '';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId, pointBalance
              FROM participant 
              WHERE userId = '$userId'";

    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];
    $pointBalance = $row['pointBalance'];

    $rewardQuery = "SELECT pointRequired
                    FROM reward
                    WHERE rewardId = '$rewardId'
                    AND status = 'Active'";

    $rewardResult = mysqli_query($conn, $rewardQuery);
    $reward = mysqli_fetch_assoc($rewardResult);

    $pointRequired = $reward['pointRequired'];

    if ($pointBalance < $pointRequired) {

        $_SESSION['submissionError'] = "You do not have enough points.";
        
        header("Location: reward.php?rewardId=" . urlencode($rewardId));
        
        exit();

    }

    if(isset($_POST["submit"])) {

        $updatePointsQuery = "UPDATE participant
                              SET pointBalance = pointBalance - {$reward['pointRequired']}
                              WHERE participantId = '$participantId'";
        $updatePoints = mysqli_query($conn, $updatePointsQuery); 
   
        $idQuery = "SELECT transactionId
                    FROM pointtransaction
                    ORDER BY transactionId DESC
                    LIMIT 1";
        $result = mysqli_query($conn, $idQuery);

        if(mysqli_num_rows($result) == 0){

            $transactionId = "T000001";

        }else{

            $lastTransaction = mysqli_fetch_assoc($result);
            $lastNumber = (int)substr($lastTransaction['transactionId'],2);
            $newNumber = $lastNumber + 1;
            $transactionId = "T".str_pad($newNumber,6,"0",STR_PAD_LEFT);
        
        }

        $idQuery = "SELECT redemptionId
                    FROM rewardredemption
                    ORDER BY redemptionId DESC
                    LIMIT 1";

        $result = mysqli_query($conn, $idQuery);

        if(mysqli_num_rows($result) == 0){

            $redemptionId = "RD000001";

        }else{

            $lastRedemption = mysqli_fetch_assoc($result);
            $lastNumber = (int)substr($lastRedemption['redemptionId'],2);
            $newNumber = $lastNumber + 1;
            $redemptionId = "RD".str_pad($newNumber,6,"0",STR_PAD_LEFT);
        
        }   
        
        $status = "Pending";
        $moderatorId = NULL;
        $redeemedDate = date("Y-m-d");
        $redeemedTime = date("H:i:s");

        $submissionId = NULL;
        $pointChange = -$reward['pointRequired'];
        $transactionType = "Redeem";
        $transactionDate = date("Y-m-d");
        $transactionTime = date("H:i:s");

        $query = "INSERT INTO rewardredemption (
                        redemptionId,
                        participantId,
                        rewardId,
                        status,
                        moderatorId,
                        redeemedDate,
                        redeemedTime
                    )
                    VALUES (
                        '$redemptionId', 
                        '$participantId', 
                        '$rewardId', 
                        '$status', 
                        NULL, 
                        '$redeemedDate', 
                        '$redeemedTime'
                    )";
                
        $insertRedemption = mysqli_query($conn, $query);

        $transactionQuery = "INSERT INTO pointtransaction (
                                    transactionId,
                                    participantId,
                                    submissionId,
                                    redemptionId,
                                    pointChange,
                                    transactionType,
                                    transactionDate,
                                    transactionTime
                                )
                            VALUES (
                                    '$transactionId',
                                    '$participantId',
                                    NULL,
                                    '$redemptionId',
                                    '$pointChange',
                                    '$transactionType',
                                    '$transactionDate',
                                    '$transactionTime'
                            )";

        $insertTransaction = mysqli_query($conn, $transactionQuery);

        if ($updatePoints && $insertRedemption && $insertTransaction) {
            
            $_SESSION['submissionSuccess'] = "Redemption submitted successfully.";

        } else {

            $_SESSION['submissionError'] = "Failed to submit redemption.";

        }

        header("Location: reward.php");
        
        exit();

    }

?>
