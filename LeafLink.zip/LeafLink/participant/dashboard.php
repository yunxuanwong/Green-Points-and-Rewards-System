<?php

    session_start(); 

    $activePage = 'dashboard';
    
    include 'participant_header.php';
    include '../database/db_connect.php';

    $userId = $_SESSION["userId"];

    $idQuery = "SELECT participantId 
                FROM participant 
                WHERE userId = '$userId'";
    $result = mysqli_query($conn, $idQuery);
    $row = mysqli_fetch_assoc($result);

    $participantId = $row['participantId'];

    $submissionQuery = "SELECT COUNT(*) AS totalSubmission
                        FROM activitysubmission
                        WHERE participantId = '$participantId'
                        AND activityId IS NOT NULL";

    $submissionResult = mysqli_query($conn, $submissionQuery);
    $submissionRow = mysqli_fetch_assoc($submissionResult);

    $totalSubmission = $submissionRow['totalSubmission'];

    $pendingQuery = "SELECT COUNT(*) AS totalPending
                        FROM activitysubmission
                        WHERE participantId = '$participantId'
                        AND status = 'Pending'
                        AND activityId IS NOT NULL";

    $pendingResult = mysqli_query($conn, $pendingQuery);
    $pendingRow = mysqli_fetch_assoc($pendingResult);

    $totalPending = $pendingRow['totalPending'];

    $approvedQuery = "SELECT COUNT(*) AS totalApproved
                        FROM activitysubmission
                        WHERE participantId = '$participantId'
                        AND status = 'Approved'
                        AND activityId IS NOT NULL";

    $approvedResult = mysqli_query($conn, $approvedQuery);
    $approvedRow = mysqli_fetch_assoc($approvedResult);

    $totalApproved = $approvedRow['totalApproved'];

    $rejectedQuery = "SELECT COUNT(*) AS totalRejected
                        FROM activitysubmission
                        WHERE participantId = '$participantId'
                        AND status = 'Rejected'
                        AND activityId IS NOT NULL";

    $rejectedResult = mysqli_query($conn, $rejectedQuery);
    $rejectedRow = mysqli_fetch_assoc($rejectedResult);

    $totalRejected = $rejectedRow['totalRejected'];

    $pointQuery = "SELECT pointBalance 
                    FROM participant 
                    WHERE participantId = '$participantId'";
    $result = mysqli_query($conn, $pointQuery);
    $row = mysqli_fetch_assoc($result);

    $pointBalance = $row['pointBalance'];

    $rewardQuery = "SELECT rewardId, rewardName, pointRequired
                    FROM reward
                    ORDER BY RAND()
                    LIMIT 3";

    $rewardResult = mysqli_query($conn, $rewardQuery);

    $activityQuery = "SELECT activitysubmission.*, activity.activityName
                      FROM activitysubmission
                      JOIN activity 
                      ON activitysubmission.activityId = activity.activityId
                      WHERE activitysubmission.participantId = '$participantId'
                      AND activitysubmission.activityId IS NOT NULL
                      ORDER BY activitysubmission.submissionDate DESC,
                            activitysubmission.submissionTime DESC
                      LIMIT 5";
    $result = mysqli_query($conn, $activityQuery);

?>

<main class="main-content">

    <div class="dashboard-welcome">

        <h1>Welcome, <?php echo $_SESSION['fullName']; ?>!</h1>
    
    </div>

    <div class="dashboard-overview">

        <div class="dashboard-top">

            <div class="submission-card">

                <h2>Total Submission</h2>
                <p><?php echo $totalSubmission; ?></p>

            </div>

            <div class="pending-card">

                <h2>Pending</h2>
                <p><?php echo $totalPending; ?></p>

            </div>

            <div class="approved-card">

                <h2>Approved</h2>
                <p><?php echo $totalApproved; ?></p>

            </div>

            <div class="rejected-card">

                <h2>Rejected</h2>
                <p><?php echo $totalRejected; ?></p>

            </div>

        </div>

        <div class="dashboard-bottom"> 

            <div class="bottom-left">

                <div class="bottom-point">

                    <h2>My Points</h2>
                    <p><?php echo $pointBalance; ?></p>

                </div>

                <div class="bottom-reward">

                    <h2>Rewards</h2>

                    <div class="reward-list">

                        <?php

                        while ($reward = mysqli_fetch_assoc($rewardResult)) {
                        
                        ?>
                                    
                            <div class="reward-item">

                                <h3><?php echo $reward['rewardName']; ?></h3>
                                <p><?php echo $reward['pointRequired']; ?> points</p>
                            </div>

                        <?php } ?>

                    </div>
                        
                </div>

            </div>

            <div class="bottom-right">

                <h2>Recent Activities</h2>

                <div class="recent-activity-header">

                    <p>Activity Name</p>
                    <p>Date</p>
                    <p>Status</p>

                </div>

                <?php  

                if ($result && mysqli_num_rows($result) > 0) {

                    while ($row = mysqli_fetch_assoc($result)) {
                        
                ?>

                        <div class="recent-activity-row">

                            <p><?php echo $row['activityName']; ?></p>

                            <p><?php echo $row['submissionDate']; ?></p>

                            <p><?php echo $row['status']; ?></p>

                        </div>

                <?php } 
                
                } else {

                ?>

                    <div class="recent-activity-empty">

                        <p>
                            You don't have any recent activities.
                        </p>

                    </div>

                <?php } ?>

            </div>

        </div>

    </div>
    
</main>

<?php

    include 'participant_footer.php';
    
?>