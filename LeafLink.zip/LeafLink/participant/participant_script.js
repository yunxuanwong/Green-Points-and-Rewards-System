function openTab(event, status) {

    document.querySelectorAll(".tab-content").forEach(tab => tab.style.display = "none");
    document.querySelectorAll(".tab-button").forEach(btn => btn.classList.remove("active"));

    document.getElementById(status).style.display = "block";
    event.currentTarget.classList.add("active");

}


function openChallengeModal(submissionId, challengeName, evidencePhoto, description, status, moderatorId, submissionDate, submissionTime) {

    document.getElementById("historyChallengeName").textContent = challengeName;
    document.getElementById("historyDescription").textContent = description || "No description provided.";
    document.getElementById("historyModerator").textContent = moderatorId || "Not assigned";
    document.getElementById("historyDate").textContent = submissionDate;
    document.getElementById("historyTime").textContent = submissionTime;
    document.getElementById("historyStatus").textContent = status;

    let evidence = document.getElementById("historyEvidence");

    evidence.innerHTML = evidencePhoto
        ? `<img src="../../uploads/evidence/${evidencePhoto}" class="history-evidence-photo">`
        : "<p>No evidence photo submitted.</p>";

    document.getElementById("historyPopup").classList.add("show");

}

function closeChallengePopup() {

    document.getElementById("historyPopup").classList.remove("show");

}


function openSubmissionModal(submissionId, activityName, evidencePhoto, description, status, moderatorId, submissionDate, submissionTime) {

    document.getElementById("historyActivityName").textContent = activityName;
    document.getElementById("historyDescription").textContent = description || "No description provided.";
    document.getElementById("historyModerator").textContent = moderatorId || "Not assigned";
    document.getElementById("historyDate").textContent = submissionDate;
    document.getElementById("historyTime").textContent = submissionTime;
    document.getElementById("historyStatus").textContent = status;

    let evidence = document.getElementById("historyEvidence");

    evidence.innerHTML = evidencePhoto
        ? `<img src="../../uploads/evidence/${evidencePhoto}" class="history-evidence-photo">`
        : "<p>No evidence photo submitted.</p>";

    document.getElementById("historyPopup").classList.add("show");

}

function closeHistoryPopup() {

    document.getElementById("historyPopup").classList.remove("show");

}


function openRedeemPopup(rewardId) { 

    document.getElementById("redeemRewardId").value = rewardId; 
    document.getElementById("redemptionPopup").style.display = "flex"; 

} 

function closeRedeemPopup() { 

    document.getElementById("redemptionPopup").style.display = "none"; 

}


function openLogoutPopup() {

    document.getElementById("logoutPopup").style.display = "flex";

}

function closeLogoutPopup() {

    document.getElementById("logoutPopup").style.display = "none";

}


function closeMessagePopup() {

    document.getElementById("messagePopup").style.display = "none";

}
