<footer>

    <div class="copyright">

        © <?php echo date("Y"); ?> LeafLink. All Rights Reserved.

    </div>

</footer>

</body>
</html>