<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$type = $_GET['type'] ?? '';
$allowedTypes = ['activity', 'reward', 'performance'];

if (!in_array($type, $allowedTypes, true)) {
    http_response_code(400);
    exit('Invalid report type.');
}

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="leaflink_' . $type . '_report_' . date('Ymd') . '.csv"');

$outputFile = fopen('php://output', 'w');

if ($type === 'activity') {

    fputcsv($outputFile, ['Submission ID', 'User', 'Activity', 'Category', 'Points', 'Status', 'Moderator', 'Submitted On']);

    $rows = db_select($conn, "
        SELECT activitysubmission.submissionId, user.fullName, activity.activityName,
               activity.category, activity.pointsReward, activitysubmission.status,
               COALESCE(moderatorUser.fullName, '') AS moderatorName,
               activitysubmission.submissionDate, activitysubmission.submissionTime
        FROM activitysubmission
        JOIN participant ON participant.participantId = activitysubmission.participantId
        JOIN user ON user.userId = participant.userId
        JOIN activity ON activity.activityId = activitysubmission.activityId
        LEFT JOIN user AS moderatorUser ON moderatorUser.userId = activitysubmission.moderatorId
        ORDER BY activitysubmission.submissionDate DESC, activitysubmission.submissionTime DESC
    ");

    foreach ($rows as $row) {
        fputcsv($outputFile, [
            $row['submissionId'], $row['fullName'], $row['activityName'], $row['category'],
            $row['pointsReward'], $row['status'], $row['moderatorName'],
            $row['submissionDate'] . ' ' . $row['submissionTime'],
        ]);
    }

} elseif ($type === 'reward') {

    fputcsv($outputFile, ['Redemption ID', 'User', 'Reward', 'Points Cost', 'Status', 'Moderator', 'Redeemed On']);

    $rows = db_select($conn, "
        SELECT rewardredemption.redemptionId, user.fullName, reward.rewardName,
               reward.pointRequired, rewardredemption.status,
               COALESCE(moderatorUser.fullName, '') AS moderatorName,
               rewardredemption.redeemedDate, rewardredemption.redeemedTime
        FROM rewardredemption
        JOIN participant ON participant.participantId = rewardredemption.participantId
        JOIN user ON user.userId = participant.userId
        JOIN reward ON reward.rewardId = rewardredemption.rewardId
        LEFT JOIN user AS moderatorUser ON moderatorUser.userId = rewardredemption.moderatorId
        ORDER BY rewardredemption.redeemedDate DESC, rewardredemption.redeemedTime DESC
    ");

    foreach ($rows as $row) {
        fputcsv($outputFile, [
            $row['redemptionId'], $row['fullName'], $row['rewardName'], $row['pointRequired'],
            $row['status'], $row['moderatorName'], $row['redeemedDate'] . ' ' . $row['redeemedTime'],
        ]);
    }

} else { 

    fputcsv($outputFile, ['Metric', 'Value']);

    $metrics = [
        'Total Users'            => db_value($conn, "SELECT COUNT(*) FROM user"),
        'Total Participants'     => db_value($conn, "SELECT COUNT(*) FROM participant"),
        'Activities Approved'    => db_value($conn, "SELECT COUNT(*) FROM activitysubmission WHERE status = 'Approved'"),
        'Activities Pending'     => db_value($conn, "SELECT COUNT(*) FROM activitysubmission WHERE status = 'Pending'"),
        'Activities Rejected'    => db_value($conn, "SELECT COUNT(*) FROM activitysubmission WHERE status = 'Rejected'"),
        'Rewards Redeemed'       => db_value($conn, "SELECT COUNT(*) FROM rewardredemption WHERE status = 'Approved'"),
        'Rewards Pending'        => db_value($conn, "SELECT COUNT(*) FROM rewardredemption WHERE status = 'Pending'"),
        'Abnormal Reports Filed' => db_value($conn, "SELECT COUNT(*) FROM abnormalreport"),
        'Total Points Issued'    => db_value($conn, "SELECT COALESCE(SUM(pointChange), 0) FROM pointtransaction WHERE pointChange > 0"),
        'Total Points Redeemed'  => db_value($conn, "SELECT COALESCE(ABS(SUM(pointChange)), 0) FROM pointtransaction WHERE transactionType = 'Redeem'"),
    ];

    foreach ($metrics as $label => $value) {
        fputcsv($outputFile, [$label, $value]);
    }
}

fclose($outputFile);
exit;
