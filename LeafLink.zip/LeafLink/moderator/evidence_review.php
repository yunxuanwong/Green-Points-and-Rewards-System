<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'activities';

$submissionId = $_GET['id'] ?? '';

$submission = db_select_one($conn, "
    SELECT activitysubmission.*, user.fullName, user.emailAddress,
           activity.activityName, activity.pointsReward, activity.category
    FROM activitysubmission
    JOIN participant ON participant.participantId = activitysubmission.participantId
    JOIN user ON user.userId = participant.userId
    JOIN activity ON activity.activityId = activitysubmission.activityId
    WHERE activitysubmission.submissionId = ?
", 's', [$submissionId]);

if (!$submission) {
    header('Location: approve_activities.php');
    exit;
}

$evidencePath = '../uploads/evidence/' . $submission['evidencePhoto'];
$evidenceFileExists = is_file(__DIR__ . '/' . $evidencePath);
?>
<?php $pageTitle = 'Evidence Review'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Activity Evidence — #<?= e($submission['submissionId']) ?></h1>

    <div class="details-card">
      <h3><i class="fa-solid fa-camera"></i> Uploaded Evidence</h3>
      <?php if ($evidenceFileExists): ?>
        <img src="<?= e($evidencePath) ?>" alt="Evidence photo" class="evidence-image">
      <?php else: ?>
        <p class="muted-note">No evidence image on file (<?= e($submission['evidencePhoto']) ?>)</p>
      <?php endif; ?>
    </div>

    <div class="details-card">
      <h3><i class="fa-solid fa-file-lines"></i> Submission Details</h3>
      <div class="details-grid">
        <div class="detail-item"><label>User</label><span><?= e($submission['fullName']) ?> (<?= e($submission['emailAddress']) ?>)</span></div>
        <div class="detail-item"><label>Activity</label><span><?= e($submission['activityName']) ?> &mdash; <?= e($submission['category']) ?></span></div>
        <div class="detail-item"><label>Points on approval</label><span><?= (int) $submission['pointsReward'] ?></span></div>
        <div class="detail-item"><label>Submitted</label><span><?= e($submission['submissionDate']) ?> at <?= e(substr($submission['submissionTime'], 0, 5)) ?></span></div>
        <div class="detail-item"><label>Status</label><span class="status <?= strtolower($submission['status']) ?>"><?= e($submission['status']) ?></span></div>
      </div>
      <div class="detail-item" style="margin-top:10px;">
        <label>Description</label>
        <p class="reason-box"><?= e($submission['description']) ?></p>
      </div>

      <?php if ($submission['status'] === 'Pending'): ?>
        <div class="modal-buttons" style="justify-content:flex-start;">
          <form method="post" action="actions/activity_action.php" style="display:inline;">
            <input type="hidden" name="submissionId" value="<?= e($submission['submissionId']) ?>">
            <input type="hidden" name="action" value="approve">
            <input type="hidden" name="redirect" value="approve_activities.php?view=pending">
            <button type="submit" class="save-btn"><i class="fa-solid fa-circle-check"></i> Approve Activity</button>
          </form>
          <form method="post" action="actions/activity_action.php" style="display:inline;" data-confirm="Reject this activity submission?">
            <input type="hidden" name="submissionId" value="<?= e($submission['submissionId']) ?>">
            <input type="hidden" name="action" value="reject">
            <input type="hidden" name="redirect" value="approve_activities.php?view=pending">
            <button type="submit" class="cancel-btn" style="background:#E53935;"><i class="fa-solid fa-circle-xmark"></i> Reject Activity</button>
          </form>
        </div>
      <?php else: ?>
        <p class="muted-note">This submission has already been <?= strtolower(e($submission['status'])) ?>.</p>
      <?php endif; ?>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
