<?php
require_once __DIR__ . '/../../database/db_connect.php';
mysqli_set_charset($conn, 'utf8mb4');
