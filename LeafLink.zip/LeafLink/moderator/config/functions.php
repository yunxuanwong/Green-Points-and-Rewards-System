<?php
session_start();

require_once __DIR__ . '/db.php';
const MODERATOR_ROLE_ID = 'R000002';

function require_moderator(): void {
    $isLoggedIn = !empty($_SESSION['userId']);
    $isModerator = ($_SESSION['roleId'] ?? '') === MODERATOR_ROLE_ID;

    if (!$isLoggedIn || !$isModerator) {
        header('Location: ../login.php');
        exit;
    }
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect_with_message(string $url, string $message): void {
    $separator = (strpos($url, '?') === false) ? '?' : '&';
    header('Location: ' . $url . $separator . 'msg=' . urlencode($message));
    exit;
}

function db_select(mysqli $conn, string $sql, string $types = '', array $params = []): array {
    $statement = mysqli_prepare($conn, $sql);
    if ($params !== []) {
        mysqli_stmt_bind_param($statement, $types, ...$params);
    }
    mysqli_stmt_execute($statement);
    $result = mysqli_stmt_get_result($statement);
    $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    mysqli_stmt_close($statement);
    return $rows;
}

function db_select_one(mysqli $conn, string $sql, string $types = '', array $params = []): ?array {
    $rows = db_select($conn, $sql, $types, $params);
    return $rows[0] ?? null;
}

function db_value(mysqli $conn, string $sql, string $types = '', array $params = []) {
    $row = db_select_one($conn, $sql, $types, $params);
    return $row ? reset($row) : null;
}

function db_run(mysqli $conn, string $sql, string $types = '', array $params = []): void {
    $statement = mysqli_prepare($conn, $sql);
    if ($params !== []) {
        mysqli_stmt_bind_param($statement, $types, ...$params);
    }
    mysqli_stmt_execute($statement);
    mysqli_stmt_close($statement);
}

function next_id(mysqli $conn, string $table, string $idColumn, string $prefix, int $digits = 6): string {
    $sql = "SELECT `$idColumn` FROM `$table` WHERE `$idColumn` LIKE ? ORDER BY `$idColumn` DESC LIMIT 1";
    $highestExistingId = db_value($conn, $sql, 's', [$prefix . '%']);

    if ($highestExistingId) {
        $numberPart = substr($highestExistingId, strlen($prefix));
        $nextNumber = (int) $numberPart + 1;
    } else {
        $nextNumber = 1;
    }

    return $prefix . str_pad((string) $nextNumber, $digits, '0', STR_PAD_LEFT);
}

function get_stats(mysqli $conn): array {
    $stats = [];

    $stats['pendingActivities'] = (int) db_value($conn,
        "SELECT COUNT(*) FROM activitysubmission WHERE status = 'Pending'"
    );

    $stats['pendingRewards'] = (int) db_value($conn,
        "SELECT COUNT(*) FROM rewardredemption WHERE status = 'Pending'"
    );

    $stats['approvedThisMonth'] = (int) db_value($conn, "
        SELECT COUNT(*) FROM activitysubmission
        WHERE status = 'Approved'
          AND MONTH(submissionDate) = MONTH(CURDATE())
          AND YEAR(submissionDate) = YEAR(CURDATE())
    ");

    $stats['abnormalReports'] = (int) db_value($conn,
        "SELECT COUNT(*) FROM abnormalreport"
    );

    return $stats;
}

function get_notifications(mysqli $conn, int $limit = 6): array {
    $sql = "
        SELECT 'activity' AS kind, submissionId AS refId, submissionDate AS d, submissionTime AS t
        FROM activitysubmission
        WHERE status = 'Pending'

        UNION ALL

        SELECT 'reward' AS kind, redemptionId AS refId, redeemedDate AS d, redeemedTime AS t
        FROM rewardredemption
        WHERE status = 'Pending'

        ORDER BY d DESC, t DESC
        LIMIT $limit
    ";

    return db_select($conn, $sql);
}
