<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'activities';

$view = 'pending';
if (($_GET['view'] ?? '') === 'history') {
    $view = 'history';
}

$searchTerm = trim($_GET['q'] ?? '');

if ($view === 'pending') {
    $whereClause = "activitysubmission.status = 'Pending'";
} else {
    $whereClause = "activitysubmission.status IN ('Approved', 'Rejected')";
}

$paramTypes = '';
$params = [];
if ($searchTerm !== '') {
    $whereClause .= " AND (user.fullName LIKE ? OR activity.activityName LIKE ?)";
    $paramTypes .= 'ss';
    $params[] = "%$searchTerm%";
    $params[] = "%$searchTerm%";
}

$submissions = db_select($conn, "
    SELECT activitysubmission.submissionId, activitysubmission.status,
           activitysubmission.submissionDate, activitysubmission.submissionTime,
           user.fullName, activity.activityName, activity.pointsReward
    FROM activitysubmission
    JOIN participant ON participant.participantId = activitysubmission.participantId
    JOIN user ON user.userId = participant.userId
    JOIN activity ON activity.activityId = activitysubmission.activityId
    WHERE $whereClause
    ORDER BY activitysubmission.submissionDate DESC, activitysubmission.submissionTime DESC
", $paramTypes, $params);
?>
<?php $pageTitle = 'Approve Activities'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Approve Activities</h1>

    <?php if (!empty($_GET['msg'])): ?>
      <div class="success-message"><?= e($_GET['msg']) ?></div>
    <?php endif; ?>

    <div class="tab-row">
      <a class="tab-btn <?= $view === 'pending' ? 'active' : '' ?>" href="approve_activities.php?view=pending">Pending Activities</a>
      <a class="tab-btn <?= $view === 'history' ? 'active' : '' ?>" href="approve_activities.php?view=history">View Approval History</a>
    </div>

    <form method="get" action="approve_activities.php" class="toolbar">
      <input type="hidden" name="view" value="<?= e($view) ?>">
      <input class="search-box" type="search" name="q" value="<?= e($searchTerm) ?>" placeholder="Search by user or activity name...">
      <button type="submit" class="filter-btn"><i class="fa-solid fa-magnifying-glass"></i>&nbsp; Search</button>
    </form>

    <div class="table-card">
      <h2><i class="fa-solid fa-list-check"></i> <?= $view === 'pending' ? 'Pending Activities' : 'Approval History' ?></h2>

      <?php if (empty($submissions)): ?>
        <div class="empty-state">No <?= $view === 'pending' ? 'pending' : 'past' ?> activity submissions found.</div>
      <?php else: ?>
        <div class="table-scroll">
        <table class="recent-table">
          <tr>
            <th>User</th>
            <th>Activity</th>
            <th>Points</th>
            <th>Evidence</th>
            <th>Status</th>
            <?php if ($view === 'pending'): ?><th>Action</th><?php endif; ?>
          </tr>

          <?php foreach ($submissions as $submission): ?>
            <tr>
              <td><?= e($submission['fullName']) ?></td>
              <td><?= e($submission['activityName']) ?></td>
              <td><?= (int) $submission['pointsReward'] ?></td>
              <td><a class="filter-btn" style="padding:8px 16px;" href="evidence_review.php?id=<?= urlencode($submission['submissionId']) ?>">View</a></td>
              <td><span class="status <?= strtolower($submission['status']) ?>"><?= e($submission['status']) ?></span></td>

              <?php if ($view === 'pending'): ?>
                <td>
                  <form class="inline" method="post" action="actions/activity_action.php" style="display:inline;">
                    <input type="hidden" name="submissionId" value="<?= e($submission['submissionId']) ?>">
                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="redirect" value="approve_activities.php?view=pending">
                    <button type="submit" class="action-btn approve-btn" title="Approve"><i class="fa-solid fa-circle-check"></i></button>
                  </form>
                  <form class="inline" method="post" action="actions/activity_action.php" style="display:inline;" data-confirm="Reject this activity submission?">
                    <input type="hidden" name="submissionId" value="<?= e($submission['submissionId']) ?>">
                    <input type="hidden" name="action" value="reject">
                    <input type="hidden" name="redirect" value="approve_activities.php?view=pending">
                    <button type="submit" class="action-btn reject-btn" title="Reject"><i class="fa-solid fa-circle-xmark"></i></button>
                  </form>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
