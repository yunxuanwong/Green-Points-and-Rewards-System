<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'rewards';

$view = 'pending';
if (($_GET['view'] ?? '') === 'history') {
    $view = 'history';
}

if ($view === 'pending') {
    $whereClause = "rewardredemption.status = 'Pending'";
} else {
    $whereClause = "rewardredemption.status IN ('Approved', 'Rejected')";
}

$redemptions = db_select($conn, "
    SELECT rewardredemption.redemptionId, rewardredemption.status,
           rewardredemption.redeemedDate, rewardredemption.redeemedTime,
           user.fullName, reward.rewardName, reward.pointRequired, reward.image
    FROM rewardredemption
    JOIN participant ON participant.participantId = rewardredemption.participantId
    JOIN user ON user.userId = participant.userId
    JOIN reward ON reward.rewardId = rewardredemption.rewardId
    WHERE $whereClause
    ORDER BY rewardredemption.redeemedDate DESC, rewardredemption.redeemedTime DESC
");

function reward_image_path(string $filename): ?string {
    $path = '../uploads/rewards/' . $filename;
    $existsOnDisk = is_file(__DIR__ . '/' . $path);
    return $existsOnDisk ? $path : null;
}
?>
<?php $pageTitle = 'Approve Rewards'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Approve Rewards</h1>

    <?php if (!empty($_GET['msg'])): ?>
      <div class="success-message"><?= e($_GET['msg']) ?></div>
    <?php endif; ?>

    <div class="tab-row">
      <a class="tab-btn <?= $view === 'pending' ? 'active' : '' ?>" href="approve_rewards.php?view=pending">Pending Redemption</a>
      <a class="tab-btn <?= $view === 'history' ? 'active' : '' ?>" href="approve_rewards.php?view=history">Redemption History</a>
    </div>

    <div class="table-card">
      <h2><i class="fa-solid fa-gift"></i> <?= $view === 'pending' ? 'Pending Redemption Requests' : 'Redemption History' ?></h2>

      <?php if (empty($redemptions)): ?>
        <div class="empty-state">No <?= $view === 'pending' ? 'pending redemption requests' : 'redemption history' ?>.</div>
      <?php else: ?>
        <div class="table-scroll">
        <table class="recent-table">
          <tr>
            <th>Picture</th><th>User</th><th>Reward</th><th>Cost (pts)</th><th>Requested</th><th>Status</th>
            <?php if ($view === 'pending'): ?><th>Action</th><?php endif; ?>
          </tr>

          <?php foreach ($redemptions as $redemption): ?>
            <?php $imagePath = reward_image_path($redemption['image']); ?>
            <tr>
              <td>
                <div class="reward-thumb">
                  <?php if ($imagePath): ?>
                    <img src="<?= e($imagePath) ?>" alt="<?= e($redemption['rewardName']) ?>">
                  <?php else: ?>
                    <span class="muted-note" style="font-size:10px;">No photo</span>
                  <?php endif; ?>
                </div>
              </td>
              <td><?= e($redemption['fullName']) ?></td>
              <td><?= e($redemption['rewardName']) ?></td>
              <td><?= (int) $redemption['pointRequired'] ?></td>
              <td><?= e($redemption['redeemedDate']) ?> <?= e(substr($redemption['redeemedTime'], 0, 5)) ?></td>
              <td><span class="status <?= strtolower($redemption['status']) ?>"><?= e($redemption['status']) ?></span></td>

              <?php if ($view === 'pending'): ?>
                <td>
                  <form method="post" action="actions/reward_action.php" style="display:inline;">
                    <input type="hidden" name="redemptionId" value="<?= e($redemption['redemptionId']) ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" class="action-btn approve-btn" title="Approve"><i class="fa-solid fa-circle-check"></i></button>
                  </form>
                  <form method="post" action="actions/reward_action.php" style="display:inline;" data-confirm="Reject this redemption and refund points to the user?">
                    <input type="hidden" name="redemptionId" value="<?= e($redemption['redemptionId']) ?>">
                    <input type="hidden" name="action" value="reject">
                    <button type="submit" class="action-btn reject-btn" title="Reject"><i class="fa-solid fa-circle-xmark"></i></button>
                  </form>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
