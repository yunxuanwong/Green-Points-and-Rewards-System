<?php
require_once __DIR__ . '/config/functions.php';

$isLoggedInModerator = !empty($_SESSION['userId']) && ($_SESSION['roleId'] ?? '') === MODERATOR_ROLE_ID;

if ($isLoggedInModerator) {
    header('Location: dashboard.php');
} else {
    header('Location: ../login.php');
}
exit;
