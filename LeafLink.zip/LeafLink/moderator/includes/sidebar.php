<?php
if (!isset($activeNav)) {
    $activeNav = '';
}

$navLinks = [
    ['key' => 'dashboard',     'href' => 'dashboard.php',           'icon' => 'fa-solid fa-gauge',              'label' => 'Dashboard'],
    ['key' => 'activities',    'href' => 'approve_activities.php',  'icon' => 'fa-solid fa-square-check',       'label' => 'Approve Activities'],
    ['key' => 'rewards',       'href' => 'approve_rewards.php',     'icon' => 'fa-solid fa-gift',               'label' => 'Approve Rewards'],
    ['key' => 'teamchallenges','href' => 'team_challenges.php',     'icon' => 'fa-solid fa-people-group',       'label' => 'Team Challenges'],
    ['key' => 'abnormal',      'href' => 'report_abnormal.php',     'icon' => 'fa-solid fa-triangle-exclamation','label' => 'Report Abnormal Activities'],
    ['key' => 'leaderboard',   'href' => 'leaderboard.php',         'icon' => 'fa-solid fa-trophy',             'label' => 'Leaderboard'],
    ['key' => 'report',        'href' => 'report.php',              'icon' => 'fa-solid fa-chart-column',       'label' => 'Report'],
];
?>
<div class="admin-sidebar">
  <ul>
    <?php foreach ($navLinks as $link): ?>
      <?php $isActive = ($activeNav === $link['key']); ?>
      <li>
        <a class="<?= $isActive ? 'active' : '' ?>" href="<?= e($link['href']) ?>" title="<?= e($link['label']) ?>">
          <i class="<?= e($link['icon']) ?>"></i>
          <span><?= e($link['label']) ?></span>
        </a>
      </li>
    <?php endforeach; ?>
    <li>
      <a class="logout-trigger" href="../logout.php" title="Logout">
        <i class="fa-solid fa-right-from-bracket"></i>
        <span>Logout</span>
      </a>
    </li>
  </ul>
</div>
