<div class="admin-footer">
  &copy; <?= date('Y') ?> LeafLink. All Rights Reserved.
</div>
