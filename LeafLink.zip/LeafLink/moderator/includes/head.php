<?php
if (!isset($pageTitle) || $pageTitle === '') {
    $pageTitle = 'Moderator Portal';
}
?>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LeafLink — <?= e($pageTitle) ?></title>

<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
</head>
