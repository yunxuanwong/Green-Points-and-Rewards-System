<?php
$notifications = get_notifications($conn);
$notificationCount = count($notifications);

$nameParts = explode(' ', trim($_SESSION['fullName'] ?? ''));
$initials = '';
foreach ($nameParts as $part) {
    if ($part !== '') {
        $initials .= strtoupper($part[0]);
    }
}
$initials = $initials !== '' ? substr($initials, 0, 2) : 'M';
?>
<div class="admin-header">
  <div class="header-left">
    <img src="../images/logo.jpg" alt="LeafLink">
  </div>

  <div class="header-right">

    <!-- Notifications -->
    <div class="notification" id="notifBtn">
      <i class="fa-solid fa-bell"></i>
      <?php if ($notificationCount > 0): ?>
        <span class="notification-count"><?= $notificationCount > 9 ? '9+' : $notificationCount ?></span>
      <?php endif; ?>

      <div class="notification-dropdown" id="notifDropdown">
        <h4><i class="fa-solid fa-triangle-exclamation"></i> Notifications</h4>

        <?php if ($notificationCount === 0): ?>
          <div class="no-notification">You're all caught up.</div>
        <?php else: ?>
          <?php foreach ($notifications as $notification): ?>
            <?php
              $isActivity = ($notification['kind'] === 'activity');
              $label = $isActivity
                  ? 'Activity submission ' . e($notification['refId']) . ' awaiting review'
                  : 'Reward redemption ' . e($notification['refId']) . ' awaiting review';
            ?>
            <div class="notification-item">
              <strong><?= $label ?></strong>
              <span class="notification-date"><?= e($notification['d']) ?> &middot; <?= e(substr($notification['t'], 0, 5)) ?></span>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>

        <a href="approve_activities.php">View All Notifications</a>
      </div>
    </div>

    <div class="profile-menu" id="profileBtn">
      <div class="profile-avatar"><?= e($initials) ?></div>
      <span><?= e($_SESSION['fullName'] ?? 'Moderator') ?></span>
      <i class="fa-solid fa-chevron-down"></i>

      <div class="profile-dropdown" id="profileDropdown">
        <a href="../logout.php" class="logout-trigger"><i class="fa-solid fa-right-from-bracket"></i>&nbsp; Logout</a>
      </div>
    </div>

  </div>
</div>

<div class="logout-modal" id="logoutModal">
  <div class="logout-modal-content">
    <div class="logout-icon"><i class="fa-solid fa-right-from-bracket"></i></div>
    <h2>Log Out?</h2>
    <p>Are you sure you want to log out of your moderator account?</p>
    <div class="logout-modal-buttons">
      <button type="button" class="logout-cancel-btn" id="logoutCancelBtn">Cancel</button>
      <a href="../logout.php" class="logout-confirm-btn">Log Out</a>
    </div>
  </div>
</div>
