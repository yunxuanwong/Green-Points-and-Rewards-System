-- =========================================================
--  MIGRATION: enforce ONE team per challenge
-- =========================================================
-- The `teammember` table has a `teamName` column that's
-- separate from `challengeId`, which means nothing in the
-- table structure itself stops two different teams from
-- joining the same challenge. This project's design is meant
-- to be one team per challenge, so these two triggers reject
-- any insert/update that would put a second, differently-named
-- team onto a challenge that already has one.
--
-- Members of the SAME team can still join freely — the check
-- only blocks a DIFFERENT team name from being added to a
-- challenge that already has members.
--
-- Run it with:
--   mysql -u root leaflink < migrations/002_enforce_one_team_per_challenge.sql
-- ---------------------------------------------------------

DELIMITER $$

CREATE TRIGGER trg_teammember_one_team_insert
BEFORE INSERT ON teammember
FOR EACH ROW
BEGIN
    DECLARE existing_team_name VARCHAR(100);

    SELECT teamName INTO existing_team_name
    FROM teammember
    WHERE challengeId = NEW.challengeId
    LIMIT 1;

    IF existing_team_name IS NOT NULL AND existing_team_name <> NEW.teamName THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'This challenge already has a different team registered. Only one team is allowed per challenge.';
    END IF;
END$$

CREATE TRIGGER trg_teammember_one_team_update
BEFORE UPDATE ON teammember
FOR EACH ROW
BEGIN
    DECLARE existing_team_name VARCHAR(100);

    SELECT teamName INTO existing_team_name
    FROM teammember
    WHERE challengeId = NEW.challengeId
      AND teamMemberId <> NEW.teamMemberId
    LIMIT 1;

    IF existing_team_name IS NOT NULL AND existing_team_name <> NEW.teamName THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'This challenge already has a different team registered. Only one team is allowed per challenge.';
    END IF;
END$$

DELIMITER ;
