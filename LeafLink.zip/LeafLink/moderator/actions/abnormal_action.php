<?php
require_once __DIR__ . '/../config/functions.php';
require_moderator();

$redirectTo = '../report_abnormal.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_with_message($redirectTo, '');
}

$submissionId = $_POST['submissionId'] ?? '';
$flagType     = trim($_POST['flagType'] ?? '');
$reasonText   = trim($_POST['reason'] ?? '');
$moderatorId  = $_SESSION['userId'];

if ($submissionId === '' || $flagType === '' || $reasonText === '') {
    redirect_with_message($redirectTo, 'Please complete all fields before submitting a report.');
}

$submission = db_select_one($conn, "SELECT submissionId, status FROM activitysubmission WHERE submissionId = ?", 's', [$submissionId]);

if (!$submission) {
    redirect_with_message($redirectTo, 'Submission not found.');
}
if ($submission['status'] !== 'Pending') {
    redirect_with_message($redirectTo, 'Only Pending submissions can be reported.');
}

$existingReport = db_select_one($conn, "SELECT abnormalId FROM abnormalreport WHERE submissionId = ?", 's', [$submissionId]);
if ($existingReport) {
    redirect_with_message($redirectTo, 'This submission has already been reported.');
}

$fullReasonText = "[$flagType] $reasonText";
$newReportId = next_id($conn, 'abnormalreport', 'abnormalId', 'AR');

db_run($conn, "
    INSERT INTO abnormalreport (abnormalId, submissionId, moderatorId, reason, reportDate)
    VALUES (?, ?, ?, ?, CURDATE())
", 'ssss', [$newReportId, $submissionId, $moderatorId, $fullReasonText]);

redirect_with_message('../report_abnormal.php?filter=' . urlencode($flagType), 'Report submitted to Administrator.');