<?php
require_once __DIR__ . '/../config/functions.php';
require_moderator();

$redirectTo = '../team_challenges.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_with_message($redirectTo, '');
}

$challengeId = $_POST['challengeId'] ?? '';
if ($challengeId === '') {
    redirect_with_message($redirectTo, 'Invalid request.');
}

$challenge = db_select_one($conn, "SELECT * FROM teamchallenge WHERE challengeId = ?", 's', [$challengeId]);
if (!$challenge) {
    redirect_with_message($redirectTo, 'Team challenge not found.');
}

$alreadyDecided = ($challenge['status'] !== 'Active' && $challenge['status'] !== 'Pending');
if ($alreadyDecided) {
    redirect_with_message($redirectTo, 'This challenge has already been decided.');
}

$teamSize = 3;

$approvedSubmissions = (int) db_value($conn, "
    SELECT COUNT(*)
    FROM teammember
    JOIN activitysubmission
      ON activitysubmission.participantId = teammember.participantId
     AND activitysubmission.status = 'Approved'
     AND activitysubmission.submissionId = (
            SELECT latest.submissionId
            FROM activitysubmission AS latest
            WHERE latest.participantId = teammember.participantId
            ORDER BY latest.submissionDate DESC, latest.submissionTime DESC
            LIMIT 1
        )
    WHERE teammember.challengeId = ?
", 's', [$challengeId]);

$allApproved = ($approvedSubmissions >= $teamSize);
$newStatus = $allApproved ? 'Approved' : 'Rejected';

db_run($conn, "UPDATE teamchallenge SET status = ? WHERE challengeId = ?", 'ss', [$newStatus, $challengeId]);

if ($allApproved) {
    $message = "Team challenge Approved — all $teamSize members' activities were Approved.";
} else {
    $message = "Team challenge Rejected — only $approvedSubmissions of $teamSize members' activities are Approved.";
}

redirect_with_message($redirectTo, $message);
