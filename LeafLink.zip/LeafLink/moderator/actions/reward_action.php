<?php
require_once __DIR__ . '/../config/functions.php';
require_moderator();

$redirectTo = '../approve_rewards.php?view=pending';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_with_message($redirectTo, '');
}

$redemptionId = $_POST['redemptionId'] ?? '';
$action       = $_POST['action'] ?? '';
$moderatorId  = $_SESSION['userId'];

$validAction = ($action === 'approve' || $action === 'reject');
if (!$validAction || $redemptionId === '') {
    redirect_with_message($redirectTo, 'Invalid request.');
}

$redemption = db_select_one($conn, "
    SELECT rewardredemption.*, reward.pointRequired, reward.rewardId
    FROM rewardredemption
    JOIN reward ON reward.rewardId = rewardredemption.rewardId
    WHERE rewardredemption.redemptionId = ?
", 's', [$redemptionId]);

if (!$redemption || $redemption['status'] !== 'Pending') {
    redirect_with_message($redirectTo, 'This redemption request has already been processed.');
}

mysqli_begin_transaction($conn);

try {
    if ($action === 'approve') {
        db_run($conn, "
            UPDATE rewardredemption SET status = 'Approved', moderatorId = ? WHERE redemptionId = ?
        ", 'ss', [$moderatorId, $redemptionId]);

        db_run($conn, "
            UPDATE reward SET stock = stock - 1 WHERE rewardId = ?
        ", 's', [$redemption['rewardId']]);

        $resultMessage = 'Reward redemption approved and marked as fulfilled.';

    } else {
        db_run($conn, "
            UPDATE rewardredemption SET status = 'Rejected', moderatorId = ? WHERE redemptionId = ?
        ", 'ss', [$moderatorId, $redemptionId]);

        db_run($conn, "
            UPDATE participant SET pointBalance = pointBalance + ? WHERE participantId = ?
        ", 'is', [$redemption['pointRequired'], $redemption['participantId']]);

        $newTransactionId = next_id($conn, 'pointtransaction', 'transactionId', 'T');
        db_run($conn, "
            INSERT INTO pointtransaction
                (transactionId, participantId, submissionId, redemptionId, pointChange, transactionType, transactionDate, transactionTime)
            VALUES (?, ?, NULL, ?, ?, 'Refund', CURDATE(), CURTIME())
        ", 'sssi', [$newTransactionId, $redemption['participantId'], $redemptionId, $redemption['pointRequired']]);

        $resultMessage = 'Reward redemption rejected and points refunded.';
    }

    mysqli_commit($conn);

} catch (Exception $error) {
    mysqli_rollback($conn);
    $resultMessage = 'Something went wrong: ' . $error->getMessage();
}

redirect_with_message($redirectTo, $resultMessage);
