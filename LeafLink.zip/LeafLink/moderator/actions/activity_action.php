<?php
require_once __DIR__ . '/../config/functions.php';
require_moderator();

$redirectTo = '../' . ltrim($_POST['redirect'] ?? 'approve_activities.php', '/');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect_with_message($redirectTo, '');
}

$submissionId = $_POST['submissionId'] ?? '';
$action       = $_POST['action'] ?? '';
$moderatorId  = $_SESSION['userId'];

$validAction = ($action === 'approve' || $action === 'reject');
if (!$validAction || $submissionId === '') {
    redirect_with_message($redirectTo, 'Invalid request.');
}

$submission = db_select_one($conn, "
    SELECT activitysubmission.*, activity.pointsReward
    FROM activitysubmission
    JOIN activity ON activity.activityId = activitysubmission.activityId
    WHERE activitysubmission.submissionId = ?
", 's', [$submissionId]);

if (!$submission || $submission['status'] !== 'Pending') {
    redirect_with_message($redirectTo, 'This submission has already been processed.');
}

mysqli_begin_transaction($conn);

try {
    if ($action === 'approve') {
        db_run($conn, "
            UPDATE activitysubmission SET status = 'Approved', moderatorId = ? WHERE submissionId = ?
        ", 'ss', [$moderatorId, $submissionId]);

        db_run($conn, "
            UPDATE participant SET pointBalance = pointBalance + ? WHERE participantId = ?
        ", 'is', [$submission['pointsReward'], $submission['participantId']]);

        $newTransactionId = next_id($conn, 'pointtransaction', 'transactionId', 'T');
        db_run($conn, "
            INSERT INTO pointtransaction
                (transactionId, participantId, submissionId, redemptionId, pointChange, transactionType, transactionDate, transactionTime)
            VALUES (?, ?, ?, NULL, ?, 'Earn', CURDATE(), CURTIME())
        ", 'sssi', [$newTransactionId, $submission['participantId'], $submissionId, $submission['pointsReward']]);

        $resultMessage = 'Activity approved and points credited.';

    } else {
        db_run($conn, "
            UPDATE activitysubmission SET status = 'Rejected', moderatorId = ? WHERE submissionId = ?
        ", 'ss', [$moderatorId, $submissionId]);

        $resultMessage = 'Activity rejected.';
    }

    mysqli_commit($conn);

} catch (Exception $error) {
    mysqli_rollback($conn);
    $resultMessage = 'Something went wrong: ' . $error->getMessage();
}

redirect_with_message($redirectTo, $resultMessage);
