<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'report';

function counts_by_status(mysqli $conn, string $sql): array {
    $rows = db_select($conn, $sql);
    $counts = [];
    foreach ($rows as $row) {
        $counts[$row['status']] = (int) $row['cnt'];
    }
    return $counts;
}

$activityCountsByStatus = counts_by_status($conn, "SELECT status, COUNT(*) AS cnt FROM activitysubmission GROUP BY status");
$rewardCountsByStatus = counts_by_status($conn, "SELECT status, COUNT(*) AS cnt FROM rewardredemption GROUP BY status");

$totalUsers = (int) db_value($conn, "SELECT COUNT(*) FROM user");
$totalParticipants = (int) db_value($conn, "SELECT COUNT(*) FROM participant");
$totalApprovedActivities = (int) ($activityCountsByStatus['Approved'] ?? 0);
$totalRewardsRedeemed = (int) ($rewardCountsByStatus['Approved'] ?? 0);
$abnormalReportsFiled = (int) db_value($conn, "SELECT COUNT(*) FROM abnormalreport");

$totalPointsIssued = (int) db_value($conn, "SELECT COALESCE(SUM(pointChange), 0) FROM pointtransaction WHERE pointChange > 0");
$totalPointsRedeemed = (int) db_value($conn, "SELECT COALESCE(ABS(SUM(pointChange)), 0) FROM pointtransaction WHERE transactionType = 'Redeem'");

function find_largest_value(array $values): int {
    $largest = 1;
    foreach ($values as $value) {
        if ((int) $value > $largest) { $largest = (int) $value; }
    }
    return $largest;
}
$largestActivityCount = find_largest_value($activityCountsByStatus);
$largestRewardCount = find_largest_value($rewardCountsByStatus);
$statusesInOrder = ['Pending', 'Approved', 'Rejected'];
?>
<?php $pageTitle = 'Report'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content report-page">
    <h1 class="dashboard-title">Report</h1>

    <div class="report-summary-grid">
      <div class="report-summary-card">
        <div class="report-summary-icon"><i class="fa-solid fa-users"></i></div>
        <div><h3><?= $totalUsers ?></h3><p>Total Users</p></div>
      </div>
      <div class="report-summary-card">
        <div class="report-summary-icon"><i class="fa-solid fa-leaf"></i></div>
        <div><h3><?= $totalParticipants ?></h3><p>Participants</p></div>
      </div>
      <div class="report-summary-card">
        <div class="report-summary-icon"><i class="fa-solid fa-square-check"></i></div>
        <div><h3><?= $totalApprovedActivities ?></h3><p>Activities Approved</p></div>
      </div>
      <div class="report-summary-card">
        <div class="report-summary-icon"><i class="fa-solid fa-gift"></i></div>
        <div><h3><?= $totalRewardsRedeemed ?></h3><p>Rewards Redeemed</p></div>
      </div>
    </div>

    <div class="report-chart-grid">
      <div class="report-chart-card">
        <div class="report-card-header">
          <h2><i class="fa-solid fa-square-check"></i> Activity Approval Report</h2>
          <a class="report-filter-btn" href="export_csv.php?type=activity"><i class="fa-solid fa-download"></i> Export CSV</a>
        </div>
        <div class="bars" style="height:220px;">
          <?php foreach ($statusesInOrder as $status): ?>
            <?php
              $count = (int) ($activityCountsByStatus[$status] ?? 0);
              $barHeightPx = round(($count / $largestActivityCount) * 180);
              if ($barHeightPx < 4) { $barHeightPx = 4; }
            ?>
            <div class="bar-col">
              <div class="bar-value"><?= $count ?></div>
              <div class="bar" style="height:<?= $barHeightPx ?>px;"></div>
              <div class="bar-label"><?= $status ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="report-chart-card">
        <div class="report-card-header">
          <h2><i class="fa-solid fa-gift"></i> Reward Approval Report</h2>
          <a class="report-filter-btn" href="export_csv.php?type=reward"><i class="fa-solid fa-download"></i> Export CSV</a>
        </div>
        <div class="bars" style="height:220px;">
          <?php foreach ($statusesInOrder as $status): ?>
            <?php
              $count = (int) ($rewardCountsByStatus[$status] ?? 0);
              $barHeightPx = round(($count / $largestRewardCount) * 180);
              if ($barHeightPx < 4) { $barHeightPx = 4; }
            ?>
            <div class="bar-col">
              <div class="bar-value"><?= $count ?></div>
              <div class="bar" style="height:<?= $barHeightPx ?>px;"></div>
              <div class="bar-label"><?= $status ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <h2 class="report-section-title">Overall System Performance</h2>
    <div class="details-card">
      <div class="details-grid">
        <div class="detail-item"><label>Total Points Issued</label><span><?= $totalPointsIssued ?></span></div>
        <div class="detail-item"><label>Total Points Redeemed</label><span><?= $totalPointsRedeemed ?></span></div>
        <div class="detail-item"><label>Abnormal Reports Filed</label><span><?= $abnormalReportsFiled ?></span></div>
        <div class="detail-item"><label>Total Users</label><span><?= $totalUsers ?></span></div>
      </div>
      <div class="modal-buttons" style="justify-content:flex-start;">
        <a class="save-btn" href="export_csv.php?type=performance"><i class="fa-solid fa-download"></i> Export CSV</a>
      </div>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
