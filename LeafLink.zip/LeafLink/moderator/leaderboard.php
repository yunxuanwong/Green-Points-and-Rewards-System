<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'leaderboard';

$view = 'overall';
if (($_GET['view'] ?? '') === 'top') {
    $view = 'top';
}

$rowLimit = ($view === 'top') ? 5 : 50;

if ($view === 'overall') {

    $rankings = db_select($conn, "
        SELECT fullName, pointBalance AS metric, participantId
        FROM (
            SELECT
                user.fullName AS fullName,
                participant.pointBalance AS pointBalance,
                participant.participantId AS participantId,
                ROW_NUMBER() OVER (
                    PARTITION BY user.fullName
                    ORDER BY participant.pointBalance DESC, participant.participantId ASC
                ) AS rn
            FROM participant
            JOIN user ON user.userId = participant.userId
        ) AS one_row_per_name
        WHERE rn = 1
        ORDER BY metric DESC
        LIMIT $rowLimit
    ");

} else {

    $rankings = db_select($conn, "
        SELECT fullName, approvedCount AS metric, participantId
        FROM (
            SELECT
                user.fullName AS fullName,
                participant.participantId AS participantId,
                (
                    SELECT COUNT(*) FROM activitysubmission
                    WHERE activitysubmission.participantId = participant.participantId
                      AND activitysubmission.status = 'Approved'
                ) AS approvedCount,
                ROW_NUMBER() OVER (
                    PARTITION BY user.fullName
                    ORDER BY (
                        SELECT COUNT(*) FROM activitysubmission
                        WHERE activitysubmission.participantId = participant.participantId
                          AND activitysubmission.status = 'Approved'
                    ) DESC, participant.participantId ASC
                ) AS rn
            FROM participant
            JOIN user ON user.userId = participant.userId
        ) AS one_row_per_name
        WHERE rn = 1
        ORDER BY metric DESC
        LIMIT $rowLimit
    ");

}
?>
<?php $pageTitle = 'Leaderboard'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Leaderboard</h1>

    <div class="tab-row">
      <a class="tab-btn <?= $view === 'overall' ? 'active' : '' ?>" href="leaderboard.php?view=overall">Overall Ranking</a>
      <a class="tab-btn <?= $view === 'top' ? 'active' : '' ?>" href="leaderboard.php?view=top">Top Green Contributors</a>
    </div>

    <div class="table-card">
      <h2><i class="fa-solid fa-trophy"></i> <?= $view === 'overall' ? 'Overall Ranking' : 'Top Green Contributors' ?></h2>

      <?php if (empty($rankings)): ?>
        <div class="empty-state">No participants found.</div>
      <?php else: ?>
        <?php foreach ($rankings as $index => $participant): ?>
          <?php
            $badges = db_select($conn, "
                SELECT badge.badgeName
                FROM participantbadge
                JOIN badge ON badge.badgeId = participantbadge.badgeId
                WHERE participantbadge.participantId = ?
                ORDER BY badge.requiredPoints ASC
            ", 's', [$participant['participantId']]);
          ?>
          <div class="rank-item">
            <div class="rank-number"><?= $index + 1 ?></div>
            <div class="rank-info" style="flex:1;">
              <strong><?= e($participant['fullName']) ?></strong>
              <small>
                <?= (int) $participant['metric'] ?> <?= $view === 'overall' ? 'points' : 'approved activities' ?>
                <?php if (!empty($badges)): ?>
                  &middot;
                  <?php foreach ($badges as $badge): ?>
                    <i class="fa-solid fa-medal"></i> <?= e($badge['badgeName']) ?>
                  <?php endforeach; ?>
                <?php endif; ?>
              </small>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
