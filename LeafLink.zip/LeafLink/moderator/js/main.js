document.addEventListener('DOMContentLoaded', function () {

  var notifBtn = document.getElementById('notifBtn');
  var notifDropdown = document.getElementById('notifDropdown');
  if (notifBtn && notifDropdown) {
    notifBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      notifDropdown.classList.toggle('show');
    });
  }

  var profileBtn = document.getElementById('profileBtn');
  var profileDropdown = document.getElementById('profileDropdown');
  if (profileBtn && profileDropdown) {
    profileBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      profileDropdown.classList.toggle('show');
    });
  }

  document.addEventListener('click', function (e) {
    if (notifDropdown && !notifDropdown.contains(e.target) && e.target !== notifBtn) {
      notifDropdown.classList.remove('show');
    }
    if (profileDropdown && !profileDropdown.contains(e.target) && e.target !== profileBtn && !profileBtn.contains(e.target)) {
      profileDropdown.classList.remove('show');
    }
  });

  document.querySelectorAll('[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!confirm(form.getAttribute('data-confirm'))) {
        e.preventDefault();
      }
    });
  });

  var logoutModal = document.getElementById('logoutModal');
  var logoutTriggers = document.querySelectorAll('.logout-trigger');
  var logoutCancelBtn = document.getElementById('logoutCancelBtn');

  if (logoutModal && logoutTriggers.length > 0) {
    logoutTriggers.forEach(function (trigger) {
      trigger.addEventListener('click', function (event) {
        event.preventDefault();
        logoutModal.classList.add('show');
      });
    });

    if (logoutCancelBtn) {
      logoutCancelBtn.addEventListener('click', function () {
        logoutModal.classList.remove('show');
      });
    }

    logoutModal.addEventListener('click', function (event) {
      if (event.target === logoutModal) {
        logoutModal.classList.remove('show');
      }
    });
  }

});
