<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'teamchallenges';

$challenges = db_select($conn, "SELECT * FROM teamchallenge ORDER BY startDate DESC");

function challenge_is_undecided(string $status): bool {
    return ($status === 'Active' || $status === 'Pending');
}
?>
<?php $pageTitle = 'Team Challenges'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Team Challenges</h1>

    <?php if (!empty($_GET['msg'])): ?>
      <div class="success-message"><?= e($_GET['msg']) ?></div>
    <?php endif; ?>

    <?php if (empty($challenges)): ?>
      <div class="table-card"><div class="empty-state">No team challenges found.</div></div>
    <?php else: ?>

      <?php foreach ($challenges as $challenge): ?>
        <?php

          $members = db_select($conn, "
              SELECT teammember.teamName, user.fullName, participant.participantId
              FROM teammember
              JOIN participant ON participant.participantId = teammember.participantId
              JOIN user ON user.userId = participant.userId
              WHERE teammember.challengeId = ?
              ORDER BY user.fullName
          ", 's', [$challenge['challengeId']]);

          $teamName = $members[0]['teamName'] ?? null;

          $statusCounts = db_select($conn, "
              SELECT activitysubmission.status, COUNT(*) AS total
              FROM teammember
              JOIN activitysubmission
                ON activitysubmission.participantId = teammember.participantId
               AND activitysubmission.submissionId = (
                      SELECT latest.submissionId
                      FROM activitysubmission AS latest
                      WHERE latest.participantId = teammember.participantId
                      ORDER BY latest.submissionDate DESC, latest.submissionTime DESC
                      LIMIT 1
                  )
              WHERE teammember.challengeId = ?
              GROUP BY activitysubmission.status
          ", 's', [$challenge['challengeId']]);

          $approvedCount = 0; $pendingCount = 0; $rejectedCount = 0;
          foreach ($statusCounts as $row) {
              if ($row['status'] === 'Approved') { $approvedCount = (int) $row['total']; }
              if ($row['status'] === 'Pending')  { $pendingCount = (int) $row['total']; }
              if ($row['status'] === 'Rejected') { $rejectedCount = (int) $row['total']; }
          }

          $teamSize = 3;
          $approvedOfTeam = min($approvedCount, $teamSize);
          $approvedPercent = round(($approvedOfTeam / $teamSize) * 100);

          if ($approvedOfTeam >= $teamSize) {
              $progressColorClass = 'full';
          } elseif ($approvedOfTeam === 2) {
              $progressColorClass = 'mid';
          } else {
              $progressColorClass = 'low';
          }

          $canBeDecided = challenge_is_undecided($challenge['status']);
        ?>

        <div class="table-card">

          <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
            <div>
              <h2 style="margin:0;"><i class="fa-solid fa-people-group"></i> <?= e($challenge['challengeName']) ?></h2>
              <?php if ($teamName): ?>
                <p style="margin:4px 0 0; font-size:15px; font-weight:bold; color:#2E7D32;">
                  <i class="fa-solid fa-users"></i> Team: <?= e($teamName) ?>
                </p>
              <?php else: ?>
                <p style="margin:4px 0 0; font-size:15px; font-weight:bold; color:#999;">No team registered yet</p>
              <?php endif; ?>
              <p class="muted-note" style="margin-top:4px;"><?= e($challenge['startDate']) ?> &rarr; <?= e($challenge['endDate']) ?></p>
            </div>
            <span class="status <?= strtolower($challenge['status']) ?>"><?= e($challenge['status']) ?></span>
          </div>

          <?php if (empty($members)): ?>
            <div class="empty-state">No team has joined this challenge yet.</div>
          <?php else: ?>
            <div class="table-scroll">
            <table class="recent-table" style="margin-bottom:16px;">
              <tr><th>Member</th></tr>
              <?php foreach ($members as $member): ?>
                <tr><td><?= e($member['fullName']) ?></td></tr>
              <?php endforeach; ?>
            </table>
            </div>
          <?php endif; ?>

          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
            <span class="muted-note" style="font-weight:bold; color:#333;">Approval Progress</span>
            <span class="progress-percent"><?= $approvedOfTeam ?>/<?= $teamSize ?></span>
          </div>
          <div class="progress-track">
            <div class="progress-fill <?= $progressColorClass ?>" style="width:<?= $approvedPercent ?>%;"></div>
          </div>

          <?php if ($pendingCount > 0 || $rejectedCount > 0): ?>
            <p style="margin:10px 0 16px;">
              <?php if ($pendingCount > 0): ?><span class="status pending"><?= $pendingCount ?> Pending</span><?php endif; ?>
              <?php if ($rejectedCount > 0): ?> <span class="status rejected"><?= $rejectedCount ?> Rejected</span><?php endif; ?>
            </p>
          <?php else: ?>
            <div style="margin-bottom:16px;"></div>
          <?php endif; ?>

          <?php if ($canBeDecided): ?>
            <form method="post" action="actions/team_challenge_action.php" data-confirm="Evaluate this challenge now? It will be Approved only if all 3 members' activities are Approved.">
              <input type="hidden" name="challengeId" value="<?= e($challenge['challengeId']) ?>">
              <button type="submit" class="save-btn"><i class="fa-solid fa-gavel"></i> Evaluate &amp; Decide</button>
            </form>
          <?php else: ?>
            <p class="muted-note">This challenge has already been <?= strtolower(e($challenge['status'])) ?>.</p>
          <?php endif; ?>

        </div>

      <?php endforeach; ?>
    <?php endif; ?>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
