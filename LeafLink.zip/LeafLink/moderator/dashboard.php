<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'dashboard';
$stats = get_stats($conn);

$categoryRows = db_select($conn, "
    SELECT activity.category AS category, COUNT(*) AS total
    FROM activitysubmission
    JOIN activity ON activity.activityId = activitysubmission.activityId
    WHERE activitysubmission.status = 'Approved'
      AND MONTH(activitysubmission.submissionDate) = MONTH(CURDATE())
      AND YEAR(activitysubmission.submissionDate) = YEAR(CURDATE())
    GROUP BY activity.category
    ORDER BY total DESC
");
$largestCategoryTotal = 1;
foreach ($categoryRows as $row) {
    if ((int) $row['total'] > $largestCategoryTotal) {
        $largestCategoryTotal = (int) $row['total'];
    }
}

$recentActivity = db_select($conn, "
    SELECT activitysubmission.status, activitysubmission.submissionDate,
           user.fullName, activity.activityName
    FROM activitysubmission
    JOIN participant ON participant.participantId = activitysubmission.participantId
    JOIN user ON user.userId = participant.userId
    JOIN activity ON activity.activityId = activitysubmission.activityId
    WHERE activitysubmission.status IN ('Approved', 'Rejected')
    ORDER BY activitysubmission.submissionDate DESC, activitysubmission.submissionTime DESC
    LIMIT 8
");

$topContributors = db_select($conn, "
    SELECT fullName, approvedCount
    FROM (
        SELECT
            user.fullName AS fullName,
            participant.participantId AS participantId,
            (
                SELECT COUNT(*) FROM activitysubmission
                WHERE activitysubmission.participantId = participant.participantId
                  AND activitysubmission.status = 'Approved'
            ) AS approvedCount,
            ROW_NUMBER() OVER (
                PARTITION BY user.fullName
                ORDER BY (
                    SELECT COUNT(*) FROM activitysubmission
                    WHERE activitysubmission.participantId = participant.participantId
                      AND activitysubmission.status = 'Approved'
                ) DESC, participant.participantId ASC
            ) AS rn
        FROM participant
        JOIN user ON user.userId = participant.userId
    ) AS one_row_per_name
    WHERE rn = 1
    ORDER BY approvedCount DESC
    LIMIT 5
");
?>
<?php $pageTitle = 'Moderator Dashboard'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Moderator Dashboard</h1>

    <?php if (!empty($_GET['msg'])): ?>
      <div class="success-message"><?= e($_GET['msg']) ?></div>
    <?php endif; ?>

    <div class="stats-container">
      <a class="stat-card" href="approve_activities.php">
        <h3><i class="fa-solid fa-square-check"></i> Pending Activities</h3>
        <h2><?= $stats['pendingActivities'] ?></h2>
      </a>
      <a class="stat-card" href="approve_rewards.php">
        <h3><i class="fa-solid fa-gift"></i> Pending Rewards</h3>
        <h2><?= $stats['pendingRewards'] ?></h2>
      </a>
      <a class="stat-card" href="report.php">
        <h3><i class="fa-solid fa-chart-line"></i> Approved This Month</h3>
        <h2><?= $stats['approvedThisMonth'] ?></h2>
      </a>
      <a class="stat-card" href="report_abnormal.php">
        <h3><i class="fa-solid fa-triangle-exclamation"></i> Abnormal Reports</h3>
        <h2><?= $stats['abnormalReports'] ?></h2>
      </a>
    </div>

    <div class="chart-card">
      <h2><i class="fa-solid fa-chart-simple"></i> Overall Summary (This Month)</h2>
      <?php if (empty($categoryRows)): ?>
        <div class="empty-state">No approved activity this month yet.</div>
      <?php else: ?>
        <div class="bars">
          <?php foreach ($categoryRows as $row): ?>
            <?php
              $barHeightPx = round(($row['total'] / $largestCategoryTotal) * 120);
              if ($barHeightPx < 6) { $barHeightPx = 6; }
            ?>
            <div class="bar-col">
              <div class="bar-value"><?= (int) $row['total'] ?></div>
              <div class="bar" style="height:<?= $barHeightPx ?>px;"></div>
              <div class="bar-label"><?= e($row['category']) ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="table-card">
      <h2><i class="fa-solid fa-clock-rotate-left"></i> Recent Moderation Activity</h2>
      <?php if (empty($recentActivity)): ?>
        <div class="empty-state">No moderation activity yet.</div>
      <?php else: ?>
        <div class="table-scroll">
        <table class="recent-table">
          <tr><th>Activity</th><th>User</th><th>Date</th><th>Status</th></tr>
          <?php foreach ($recentActivity as $row): ?>
            <tr>
              <td><?= e($row['activityName']) ?></td>
              <td><?= e($row['fullName']) ?></td>
              <td><?= e($row['submissionDate']) ?></td>
              <td><span class="status <?= strtolower($row['status']) ?>"><?= e($row['status']) ?></span></td>
            </tr>
          <?php endforeach; ?>
        </table>
        </div>
      <?php endif; ?>
    </div>

    <div class="top-activities-card">
      <h2><i class="fa-solid fa-trophy"></i> Top Green Contributors</h2>
      <?php if (empty($topContributors)): ?>
        <div class="empty-state">No participants found.</div>
      <?php else: ?>
        <?php foreach ($topContributors as $index => $row): ?>
          <div class="rank-item">
            <div class="rank-number"><?= $index + 1 ?></div>
            <div class="rank-info">
              <strong><?= e($row['fullName']) ?></strong>
              <small><?= (int) $row['approvedCount'] ?> approved activities</small>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
