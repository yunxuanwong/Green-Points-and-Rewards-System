<?php
require_once __DIR__ . '/config/functions.php';
require_moderator();

$activeNav = 'abnormal';

$flagTypes = [
    'Duplicate Submission' => 'Duplicate',
    'Fake Evidence'        => 'Fake Evidence',
    'High Point Claim'     => 'High Point',
];

$selectedFlag = $_GET['filter'] ?? 'Duplicate Submission';
if (!array_key_exists($selectedFlag, $flagTypes)) {
    $selectedFlag = 'Duplicate Submission';
}
$searchKeyword = $flagTypes[$selectedFlag];

$reports = db_select($conn, "
    SELECT abnormalreport.abnormalId, abnormalreport.submissionId, abnormalreport.moderatorId,
           abnormalreport.reason, abnormalreport.reportDate, abnormalreport.remark
    FROM abnormalreport
    WHERE abnormalreport.reason LIKE ?
    ORDER BY abnormalreport.reportDate DESC
", 's', ["%$searchKeyword%"]);

$reportableSubmissions = db_select($conn, "
    SELECT activitysubmission.submissionId, user.fullName, activity.activityName,
           activitysubmission.submissionDate, activitysubmission.status
    FROM activitysubmission
    JOIN participant ON participant.participantId = activitysubmission.participantId
    JOIN user ON user.userId = participant.userId
    JOIN activity ON activity.activityId = activitysubmission.activityId
    WHERE activitysubmission.status = 'Pending'
      AND activitysubmission.submissionId NOT IN (SELECT submissionId FROM abnormalreport)
    ORDER BY activitysubmission.submissionDate DESC
    LIMIT 50
");
?>
<?php $pageTitle = 'Report Abnormal Activities'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include __DIR__ . '/includes/head.php'; ?>
<body>
<div class="admin-container">
  <?php include __DIR__ . '/includes/header.php'; ?>
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <div class="main-content">
    <h1 class="dashboard-title">Report Abnormal Activities</h1>

    <?php if (!empty($_GET['msg'])): ?>
      <div class="success-message"><?= e($_GET['msg']) ?></div>
    <?php endif; ?>

    <div class="tab-row">
      <?php foreach ($flagTypes as $label => $keyword): ?>
        <a class="tab-btn <?= $selectedFlag === $label ? 'active' : '' ?>" href="report_abnormal.php?filter=<?= urlencode($label) ?>">
          <?= e($label) ?>
        </a>
      <?php endforeach; ?>
    </div>

    <div class="table-card">
      <h2><i class="fa-solid fa-triangle-exclamation"></i> Flagged Submissions &mdash; <?= e($selectedFlag) ?></h2>

      <?php if (empty($reports)): ?>
        <div class="empty-state">No submissions reported under "<?= e($selectedFlag) ?>" yet.</div>
      <?php else: ?>
        <div class="table-scroll">
        <table class="recent-table">
          <tr><th>Abnormal ID</th><th>Submission ID</th><th>Moderator ID</th><th>Reason</th><th>Report Date</th><th>Remark</th></tr>
          <?php foreach ($reports as $report): ?>
            <tr>
              <td><?= e($report['abnormalId']) ?></td>
              <td><a href="approve_activities.php"><?= e($report['submissionId']) ?></a></td>
              <td><?= e($report['moderatorId']) ?></td>
              <td><?= e($report['reason']) ?></td>
              <td><?= e($report['reportDate']) ?></td>
              <td style="min-width:180px;">
                <?php if (!empty($report['remark'])): ?>
                  <?= nl2br(e($report['remark'])) ?>
                <?php else: ?>
                  <span class="muted-note">No remark from admin yet.</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </table>
        </div>
      <?php endif; ?>
    </div>

    <div class="table-card">
      <h2><i class="fa-solid fa-envelope"></i> Report a New Abnormal Submission</h2>

      <form method="post" action="actions/abnormal_action.php">
        <input type="hidden" name="flagType" value="<?= e($selectedFlag) ?>">

        <div class="form-group">
          <label>Pending Activity Submission</label>
          <select name="submissionId" required>
            <?php if (empty($reportableSubmissions)): ?>
              <option value="">-- No pending submissions to report --</option>
            <?php else: ?>
              <option value="">-- Select a submission --</option>
              <?php foreach ($reportableSubmissions as $candidate): ?>
                <option value="<?= e($candidate['submissionId']) ?>">
                  <?= e($candidate['submissionId']) ?> — <?= e($candidate['fullName']) ?> — <?= e($candidate['activityName']) ?>
                  (<?= e($candidate['status']) ?>, <?= e($candidate['submissionDate']) ?>)
                </option>
              <?php endforeach; ?>
            <?php endif; ?>
          </select>
        </div>

        <div class="form-group">
          <label>Moderator Notes / Reason</label>
          <textarea name="reason" rows="3" required placeholder="Explain why this submission looks abnormal..."></textarea>
        </div>

        <button type="submit" class="save-btn"><i class="fa-solid fa-paper-plane"></i> Submit Report to Admin</button>
      </form>
    </div>

  </div>
  <?php include __DIR__ . '/includes/app_footer.php'; ?>
</div>
<script src="js/main.js"></script>
</body>
</html>
